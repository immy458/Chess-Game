function bishopcheck(data,idd)
{
	var m1=new Array();
	var m2=new Array();
	var m3=new Array();
	var m4=new Array();
	//alert("highlight");
	var leftfrontking=0,leftbackking=0,rightbackking=0,rightfrontking=0;
	var x;
	var pathimg="";
	var k=0;
	var tempflag=0;
	var a=0,b=0,c=0,d=0;

	if((data=="wb1")||(data=="wb2")||(data=="bb1")||(data=="bb2")||(data=="wq1")||(data=="bq1"))
	{
		e=parseInt(idd)-99; //to move front diagonally left
		x=checkrange(e);
		if(x)
		{
			m1[a]=e;
			a++;
		}
		e=parseInt(idd)+99; //to move backwards diagonally left
		x=checkrange(e);
		if(x)
		{
			m2[b]=e;
			b++;
		}
		e=parseInt(idd)-101; //to move backwards diagonally right
		x=checkrange(e);
		if(x)
		{
			m3[c]=e;
			c++;
		}
		e=parseInt(idd)+101; //to move front diagonally right
		x=checkrange(e);
		if(x)
		{
			m4[d]=e;
			d++;
		}
		
		for(var i=1;i<8;i++)
		{
			var e;
			e=m1[i-1]-99;
			x=checkrange(e);
			if(x)
			{
				m1[a]=e;
				a++;
			}
			e=m2[i-1]+99;
			x=checkrange(e);
			if(x)
			{
				m2[b]=e;
				b++;
			}
			e=m3[i-1]-101;
			x=checkrange(e);
			if(x)
			{
				m3[c]=e;
				c++;
			}
			e=m4[i-1]+101;
			x=checkrange(e);
			if(x)
			{
				m4[d]=e;
				d++;
			}
		}

	if((data=="wb1")||(data=="wb2")||(data=="wq1"))
	{
		
		if(m1.length!=0)	
		{
			var x;
			for(var j=0;j<a;j++)
			{
				//------checks if king piece is present in ids present in array m1---
				x=document.getElementById(m1[j]).contains(document.getElementById("bk1"));	
				if(x)						
				{
					leftfrontking=1;	//king present in diagonally left front divs
					k=j+1;			//kingposition
					break;
				}
			}
		}
		if(m2.length!=0)
		{
			var x;
			for(var j=0;j<b;j++)
			{
				//------checks if king piece is present in ids present in array m2---
				x=document.getElementById(m2[j]).contains(document.getElementById("bk1"));	
				if(x)	
				{
					leftbackking=1;	//king present in diagonally left back divs
					k=j+1;			//kingposition
					break;
				}
			}
		}
		if(m3.length!=0)
		{
			var x;
			for(var j=0;j<c;j++)
			{
				//------checks if king piece is present in ids present in array m3---
				x=document.getElementById(m3[j]).contains(document.getElementById("bk1"));	
				if(x)	
				{
					rightbackking=1;	//king present in diagonally right back divs
					k=j+1;			//kingposition
					break;
				}
			}
		}
		if(m4.length!=0)
		{
			
			var x;
			for(var j=0;j<d;j++)
			{
				//------checks if king piece is present in ids present in array m4---
				x=document.getElementById(m4[j]).contains(document.getElementById("bk1"));	
				if(x)	
				{
					rightfrontking=1;	//king present in diagonally right front divs
					k=j+1;			//kingposition
					break;
				}
			}
		}
	
	}
	if((data=="bb1")||(data=="bb2")||(data=="bq1"))
	{
		if(m1.length!=0)	
		{
			for(var j=0;j<a;j++)
			{
				//------checks if king piece is present in ids present in array m1---
				x=document.getElementById(m1[j]).contains(document.getElementById("wk1"));	
				if(x)						
				{
					leftfrontking=1;	//king present in diagonally left front divs
					k=j+1;			//kingposition
					break;
				}
			}
		}
		if(m2.length!=0)
			{
				for(var j=0;j<b;j++)
				{
					//------checks if king piece is present in ids present in array m2---
					x=document.getElementById(m2[j]).contains(document.getElementById("wk1"));	
					if(x)	
					{
						leftbackking=1;	//king present in diagonally left back divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m3.length!=0)
			{
				for(var j=0;j<c;j++)
				{
					//------checks if king piece is present in ids present in array m3---
					x=document.getElementById(m3[j]).contains(document.getElementById("wk1"));	
					if(x)	
					{
						rightbackking=1;	//king present in diagonally right back divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m4.length!=0)
			{
				for(var j=0;j<d;j++)
				{
					//------checks if king piece is present in ids present in array m4---
					x=document.getElementById(m4[j]).contains(document.getElementById("wk1"));	
					if(x)	
					{
						rightfrontking=1;	//king present in diagonally right front divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
	}

		if(k>0)	//------------king present in the path----------
		{
			for(var i=0;i<imageid.length;i++)
			{
				//------------checks for any chess piece in between bishop and king---------------
					
						if(leftfrontking==1)	//front path
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
								if(x)						//chess piece present in the path
								{
									pathimg=imageid[i];		
									tempflag=1;
									break;
								}
							}
						}
						if(leftbackking==1)
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
								if(x)	//chess piece present in the path
								{
									pathimg=imageid[i];	
									tempflag=1;
									break;
								}
							}
						}
						if(rightbackking==1)
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
								if(x)	//chess piece present in the path
								{
									pathimg=imageid[i];	
									tempflag=1;
									break;
								}
							}
						}
						if(rightfrontking==1)
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
								if(x)	//chess piece present in the path
								{
									pathimg=imageid[i];	
									tempflag=1;
									break;
								}
							}
						}
					
			}
			if((pathimg=="")&&(tempflag==0))	// no chess piece present in between rook and king
			{
				alert("CHECK!!");
				document.getElementById(parseInt(idd)).style.border="2px solid red";
				if((data=="wb1")||(data=="wb2")||(data=="wq1"))
				{
					return "bk1";
				}
				else
				{
					return "wk1";
				}
				
			}
			else
			{
				return false;
			}
			
		}
	}
}

function bishophighlight(highlightdata)
{
	var m1=new Array();
	var m2=new Array();
	var m3=new Array();
	var m4=new Array();
	//alert("highlight");
	var data=highlightdata;
	
	var a=0,b=0,c=0,d=0;

	if((data=="wb1")||(data=="wb2")||(data=="bb1")||(data=="bb2")||(data=="wq1")||(data=="bq1"))
	{
		e=parseInt(draggeddiv)-99; //to move front diagonally left
		x=checkrange(e);
		if(x)
		{
			m1[a]=e;
			a++;
		}
		e=parseInt(draggeddiv)+99; //to move backwards diagonally left
		x=checkrange(e);
		if(x)
		{
			m2[b]=e;
			b++;
		}
		e=parseInt(draggeddiv)-101; //to move backwards diagonally right
		x=checkrange(e);
		if(x)
		{
			m3[c]=e;
			c++;
		}
		e=parseInt(draggeddiv)+101; //to move front diagonally right
		x=checkrange(e);
		if(x)
		{
			m4[d]=e;
			d++;
		}
		
		for(var i=1;i<8;i++)
		{
			var e;
			e=m1[i-1]-99;
			x=checkrange(e);
			if(x)
			{
				m1[a]=e;
				a++;
			}
			e=m2[i-1]+99;
			x=checkrange(e);
			if(x)
			{
				m2[b]=e;
				b++;
			}
			e=m3[i-1]-101;
			x=checkrange(e);
			if(x)
			{
				m3[c]=e;
				c++;
			}
			e=m4[i-1]+101;
			x=checkrange(e);
			if(x)
			{
				m4[d]=e;
				d++;
			}
		}
		
		if(m1.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
			var x="";
				for(var j=0;j<a;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wb1")||(data=="wb2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;		//to break from the other loop
					}
					if(k>0)
					{
						break;
					}
				}
		//		alert("K:" +k);
			//	alert("x" +x);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m1[j]).style.background="grey";
					}
				}
				
				if(!x)
				{
					
					for(var j=0;j<a;j++)		//array length
					{
						document.getElementById(m1[j]).style.background="grey";
					}
				}
			
		}
		if(m2.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
				var x="";
				for(var j=0;j<b;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wb1")||(data=="wb2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;
					}
					if(k>0)
					{
						break;
					}
				}
			//	alert("K:" +k);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m2[j]).style.background="grey";
					}
				}
				if(!x)
				{
					
					for(var j=0;j<b;j++)		//array length
					{
						document.getElementById(m2[j]).style.background="grey";
					}
				}

		}
		
		if(m3.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
				var x="";
				for(var j=0;j<c;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wb1")||(data=="wb2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;
					}
					if(k>0)
					{
						break;
					}
				}
			//	alert("K:" +k);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m3[j]).style.background="grey";
					}
				}
				if(!x)
				{
					
					for(var j=0;j<c;j++)		//array length
					{
						document.getElementById(m3[j]).style.background="grey";
					}
				}
		
		}
		if(m4.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
		
				var x="";
				for(var j=0;j<d;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wb1")||(data=="wb2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//break from inner loop
						}
					}
					if(flag==1)
					{
						break;
					}
					if(k>0)
					{
						break;
					}
				}
			//	alert("K:" +k);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m4[j]).style.background="grey";
					}
				}
				if(!x)
				{
					
					for(var j=0;j<d;j++)		//array length
					{
						document.getElementById(m4[j]).style.background="grey";
					}
				}
		}
		
	}
}



function bishopcapture(idd,data,ev)
{
	var img="";
	var x;
	//------------------checks if the dropzone contains an image----------------
	for(var i=0;i<imageid.length;i++)
	{
		 x=document.getElementById(idd).contains(document.getElementById(imageid[i]));	
		if(x)	//contains an image
		{
			img=imageid[i];		//image id is stored in variable img
			break;
		}
	}
	
	if(x)
	{
		if((data=="wb1")||(data=="wb2"))//checks if white bishop
		{
			if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
					(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white bishop it can capture any black piece
			{
				//------------ removes  chess piece of the opponent from the dropzone.---------
				var el = ev.target;
				if (!el.classList.contains('dropzone')) 
				{
				   el = ev.target.parentNode;
				   ev.target.remove();
				    var chk=checkemptydivblack();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
				}
				 el.appendChild(document.getElementById(data));
				//-------------------------------------checks for illegal move--------------------	
 
				var t=check();
				if(t=="wk1")
				{
					alert("illegal move!!");
					document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
					document.getElementById(draggeddiv).appendChild(document.getElementById(data));
					document.getElementById(idtest).appendChild(ev.target);
					
					return false;
				}
				else if(t=="bk1")
				{
					checkmate(t);
				}
				
			}
			else			//----------reset turn if dropzone contains white piece----------
			{
				alert("Invalid Move!!");
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				return false;
			}
		}
		else if((data=="bb1")||(data=="bb2"))//checks if black bishop
		{
			if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
					(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
			{
				//------------ removes  chess piece of the opponent from the dropzone.---------
				var el = ev.target;
				//alert("el :" +el);
				if (!el.classList.contains('dropzone')) 
				{
				   el = ev.target.parentNode;
				   ev.target.remove();
				    var chk=checkemptydivwhite();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
				}
				 el.appendChild(document.getElementById(data));
				
				//-------------------------------------checks for illegal move--------------------	
				var t=check();
				if(t=="bk1")
				{
					alert("illegal move!!");
					turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
					document.getElementById(draggeddiv).appendChild(document.getElementById(data));
					document.getElementById(idtest).appendChild(ev.target);
					return false;
				}
				else if(t=="wk1")
				{
					checkmate(t);
				}				
			}
			else			//----------reset turn if dropzone contains black piece----------
			{
				alert("Invalid Move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
		}
	}
	else	//----------dropzone empty-------------
	{
		ev.target.appendChild(document.getElementById(data));
		
		//-------------------------------------checks for illegal move--------------------	
		if((data=="wb1")||(data=="wb2"))
		{
			var t=check();
			if(t=="wk1")
			{
				alert("illegal move!!");
			document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				document.getElementById(draggeddiv).appendChild(document.getElementById(data));
				document.getElementById(idtest).appendChild(ev.target);
				return false;
			}
			else if(t=="bk1")
			{
				checkmate(t);
			}
		}
		else 
		{
			var t=check();
			if(t=="bk1")
			{
				alert("illegal move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				document.getElementById(draggeddiv).appendChild(document.getElementById(data));
				document.getElementById(idtest).appendChild(ev.target);
				return false;
			}
			else if(t=="wk1")
			{
				checkmate(t);
			}
		}
	}
	
	bishopcheck(data,idd);
}

function bishopmove(data,ev,idd)
{
	var m1=new Array();
	var m2=new Array();
	var m3=new Array();
	var m4=new Array();
	var drop=1;
	var lfront=0,lback=0,rfront=0,rback=0;
	var k=0;
	var e,x;

	if((data=="wb1")||(data=="wb2")||(data=="bb1")||(data=="bb2"))
	{
		e=parseInt(draggeddiv)-99; //to move front diagonally left
		x=checkrange(e);
		if(x)
		{
			m1[0]=e;
		}
		e=parseInt(draggeddiv)+99; //to move backwards diagonally left
		x=checkrange(e);
		if(x)
		{
			m2[0]=e;
		}
		e=parseInt(draggeddiv)-101; //to move backwards diagonally right
		x=checkrange(e);
		if(x)
		{
			m3[0]=e;
		}
		e=parseInt(draggeddiv)+101; //to move front diagonally right
		x=checkrange(e);
		if(x)
		{
			m4[0]=e;
		}
		
		for(var i=1;i<8;i++)
		{
			e=m1[i-1]-99;
			x=checkrange(e);
			if(x)
			{
				m1[i]=e;
			}
			e=m2[i-1]+99;
			x=checkrange(e);
			if(x)
			{
				m2[i]=e;
			}
			e=m3[i-1]-101;
			x=checkrange(e);
			if(x)
			{
				m3[i]=e;
			}
			e=m4[i-1]+101;
			x=checkrange(e);
			if(x)
			{
				m4[i]=e;
			}
		}
		
		
		for(var i=0;i<8;i++)
		{
			if(m1[i]==parseInt(idd))
			{
				drop=0;		//can be moved as drop id belong in the bishop's path
				lfront=1;
				k=i+1;
				break;
			}
			if(m2[i]==parseInt(idd))
			{
				drop=0;
				lback=1;
				k=i+1;
				break;
			}
			if(m3[i]==parseInt(idd))
			{
				drop=0;
				rback=1;
				k=i+1;
				break;
			}
			if(m4[i]==parseInt(idd))
			{
				drop=0;
				rfront=1;
				k=i+1;
				break;
			}
		}
		if(drop==0)	//---------bishop piece can be moved--------
		{
			var x;
			var pathimg="";
			for(var i=0;i<imageid.length;i++)
			{
				
				//------------checks for chess piece in the path----------------
				for(var j=0;j<k-1;j++)	//path between draggeddiv and dropzone
				{
					if(lfront==1)	//front path
					{
						
						x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
						if(x)						//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					}
					if(lback==1)
					{
						//alert("left path");
						x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
						if(x)	//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					
					}
					if(rback==1)
					{
						//alert("right path");
						x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
						if(x)	//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					}
					if(rfront==1)
					{
						//alert("back path");
						x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
						if(x)	//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					}
				}
			}
		//	alert("path: "+pathimg)
			if(pathimg!="")	//chess piece present in path
			{
				alert("INVALID MOVE");
				if((data=="wb1")||(data=="wb2")) 	//---------reset turn---------
				{
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
					return false;
				}
				else
				{
					turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
					return false;
				}
			}
			else			//no chess piece in path
			{
				bishopcapture(idd,data,ev);
			}
		}
		else
		{
			alert("Invalid Move!!");
			if((data=="wb1")||(data=="wb2")) //---------reset turn---------
			{
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				return false;
			}
			else
			{
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
		}
	}
	
}
