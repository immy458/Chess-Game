//**************************************************************************************************************************************
//-------------------------------------function for rook check---------------------------------------------------------------------------
//**************************************************************************************************************************************

function rookcheck(data,idd)
{
	
	var m1=new Array();
	var m2=new Array();
	var m3=new Array();
	var m4=new Array();
	var frontking=0,leftking=0,rightking=0,backking=0;
	var x;
	var a=0,b=0,c=0,d=0;
	var pathimg="";
	var k=0;
	var tempflag=0;
	
	if((data=="wr1")||(data=="wr2")||(data=="br1")||(data=="br2")||(data=="wq1")||(data=="bq1"))
	{
		
		var e=parseInt(idd)+1; //front	
		//------------code to add only valid front div ids in array m1----------
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
		(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m1[a]=e;
			a++;
		}
			//------------code to add only valid left div ids in array m2----------
		e=parseInt(idd)-100; //left
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m2[b]=e; 
			b++;
		}
		e=parseInt(idd)+100; //right
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m3[c]=e; 
			c++;
		}
		e=parseInt(idd)-1; //back
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m4[d]=e; //front
			d++;
		}
		for(var i=1;i<8;i++)
		{
			var e;
			e=m1[i-1]+1;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m1[a]=e;
				a++;
			}
			e=m2[i-1]-100;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m2[b]=e; //front
				b++;
			}
			e=m3[i-1]+100;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m3[c]=e; //front
				c++;
			}
			
			e=m4[i-1]-1;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m4[d]=e; //front
				d++;
			}
		}
		/*alert("front" +m1);
		alert("lef" +m2);
		alert("righ" +m3);
		alert("bac" +m4);*/
		
		if((data=="wr1")||(data=="wr2")||(data=="wq1"))
		{
			//alert("red");
			if(m1.length!=0)	
			{
				for(var j=0;j<a;j++)
				{
					//------checks if king piece is present in div present in array m1---
					x=document.getElementById(m1[j]).contains(document.getElementById("bk1"));	
					if(x)						
					{
						frontking=1;	//king present in front divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			//alert("m2 length :" +m2.length);
			if(m2.length!=0)
			{
				for(var j=0;j<b;j++)
				{
					//------checks if king piece is present in div present in array m2---
					x=document.getElementById(m2[j]).contains(document.getElementById("bk1"));	
					if(x)	
					{
						leftking=1;	//king present in left divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m3.length!=0)
			{
				for(var j=0;j<c;j++)
				{
					//------checks if king piece is present in div present in array m3---
					x=document.getElementById(m3[j]).contains(document.getElementById("bk1"));	
					if(x)	
					{
						rightking=1;	//king present in right divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m4.length!=0)
			{
				for(var j=0;j<d;j++)
				{
					//------checks if king piece is present in div present in array m4---
					x=document.getElementById(m4[j]).contains(document.getElementById("bk1"));	
					if(x)	
					{
						backking=1;	//king present in back divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
		}	
		if((data=="br1")||(data=="br2")||(data=="bq1"))
		{
		
			if(m1.length!=0)
			{
				for(var j=0;j<a;j++)
				{
					x=document.getElementById(m1[j]).contains(document.getElementById("wk1"));	
					if(x)						
					{
					
						frontking=1;	//king present in front divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m2.length!=0)
			{
				for(var j=0;j<b;j++)
				{
					x=document.getElementById(m2[j]).contains(document.getElementById("wk1"));
					if(x)	
					{
						leftking=1;	//king present in left divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m3.length!=0)
			{
				for(var j=0;j<c;j++)
				{
					x=document.getElementById(m3[j]).contains(document.getElementById("wk1"));	
					if(x)	
					{
						rightking=1;	//king present in right divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
			if(m4.length!=0)
			{
				for(var j=0;j<d;j++)
				{
					x=document.getElementById(m4[j]).contains(document.getElementById("wk1"));	
					if(x)	
					{
						backking=1;	//king present in back divs
						k=j+1;			//kingposition
						break;
					}
				}
			}
		}
		if(k>0)	//------------king present in the path----------
		{
			for(var i=0;i<imageid.length;i++)
			{
				//------------checks for any chess piece in between rook and king---------------
					
						if(frontking==1)	//front path
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
								if(x)						//chess piece present in the path
								{
									pathimg=imageid[i];		
									tempflag=1;
									break;
								}
							}
						}
						if(leftking==1)
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
								if(x)	//chess piece present in the path
								{
									pathimg=imageid[i];	
									tempflag=1;
									break;
								}
							}
						}
						if(rightking==1)
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
								if(x)	//chess piece present in the path
								{
									pathimg=imageid[i];	
									tempflag=1;
									break;
								}
							}
						}
						if(backking==1)
						{
							for(var j=0;j<k-1;j++)	//path between rook and king
							{
								x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
								if(x)	//chess piece present in the path
								{
									pathimg=imageid[i];	
									tempflag=1;
									break;
								}
							}
						}
					
			}
			if((pathimg=="")&&(tempflag==0))	// no chess piece present in between rook and king
			{
				alert("CHECK!!");
				document.getElementById(parseInt(idd)).style.border="2px solid red";
				
				if((data=="wr1")||(data=="wr2")||(data=="wq1"))
				{
					return "bk1";
				}
				else
				{
					return "wk1";
				}
			}
			else
			{
				return false;
			}
			
		}
		
	}
}


//**************************************************************************************************************************************
//--------------------------------------------function for rook to capture---------------------------------------------------------------
//**************************************************************************************************************************************

function rookcapture(idd,data,ev){
	var img="";
	var x;
	
	//------------------checks if the dropzone contains an image----------------
	for(var i=0;i<imageid.length;i++)
	{
		 x=document.getElementById(idd).contains(document.getElementById(imageid[i]));	
		if(x)	//contains an image
		{
			img=imageid[i];		//image id is stored in variable img
			break;
		}
	}
	
	if(x)
	{
		if((data=="wr1")||(data=="wr2"))//checks if white rook
		{
			if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
					(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white rook it can capture any black piece
			{
				//------------ removes  chess piece of the opponent from the dropzone.---------
				var el = ev.target;
				if (!el.classList.contains('dropzone')) 
				{
				   el = ev.target.parentNode;
				   ev.target.remove();
				    var chk=checkemptydivblack();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
				}
				 el.appendChild(document.getElementById(data));
				 
				//-------------------------------------checks for illegal move--------------------	
				var t=check();
				if(t=="wk1")
				{
					alert("illegal move!!");
					document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
					document.getElementById(draggeddiv).appendChild(document.getElementById(data));
					document.getElementById(idtest).appendChild(ev.target);
					return false;
				}
				else if(t=="bk1")
				{
					checkmate(t);
				}
				 
				
			}
			else			//----------reset turn if dropzone contains white piece----------
			{
				alert("Invalid Move!!");
			document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				return false;
			}
		}
		else if((data=="br1")||(data=="br2"))//checks if black rook
		{
			if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
					(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
			{
				//------------ removes  chess piece of the opponent from the dropzone.---------
				var el = ev.target;
				//alert("el :" +el);
				if (!el.classList.contains('dropzone')) 
				{
				   el = ev.target.parentNode;
				   ev.target.remove();
				    var chk=checkemptydivwhite();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
				}
				 el.appendChild(document.getElementById(data));
				
				//-------------------------------------checks for illegal move--------------------	
				var t=check();
				if(t=="bk1")
				{
					alert("illegal move!!");
					turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
					document.getElementById(draggeddiv).appendChild(document.getElementById(data));
					document.getElementById(idtest).appendChild(ev.target);
					return false;
				}
				else if(t=="wk1")
				{
					checkmate(t);
				}				
				
			}
			else			//----------reset turn if dropzone contains black piece----------
			{
				alert("Invalid Move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
		}
	}
	else	//----------dropzone empty-------------
	{
		ev.target.appendChild(document.getElementById(data));
		
		//-------------------------------------checks for illegal move--------------------	
		if((data=="wr1")||(data=="wr2"))
		{
			var t=check();
			if(t=="wk1")
			{
				alert("illegal move111!!");
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				document.getElementById(draggeddiv).appendChild(document.getElementById(data));
				document.getElementById(idtest).appendChild(ev.target);
				
				return false;
			}
			else if(t=="bk1")
			{
				checkmate(t);
			}
		}
		else 
		{
			var t=check();
			if(t=="bk1")
			{
				alert("illegal move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				document.getElementById(draggeddiv).appendChild(document.getElementById(data));
				document.getElementById(idtest).appendChild(ev.target);
				return false;
			}
			else if(t=="wk1")
			{
				checkmate(t);
			}
		}
	}
	
	//----------------------rook check-------------------
	rookcheck(data,idd);
}


//**************************************************************************************************************************************
//--------------------------------------------------function highlight------------------------------------------------------------------
//**************************************************************************************************************************************

function rookhighlight(draggeddiv,data)
{
	
	var m1=new Array();
	var m2=new Array();
	var m3=new Array();
	var m4=new Array();
	var a=0,b=0,c=0,d=0;
//	alert("here");
	
	if((data=="wr1")||(data=="wr2")||(data=="br1")||(data=="br2")||(data=="wq1")||(data=="bq1"))
	{
		var e=parseInt(draggeddiv)+1; //front	
		//------------code to add only valid front div ids in array m1----------
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
		(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m1[a]=e;
			a++;
		}
			//------------code to add only valid left div ids in array m2----------
		e=parseInt(draggeddiv)-100; //left
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m2[b]=e; 
			b++;
		}
		e=parseInt(draggeddiv)+100; //right
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m3[c]=e; 
			c++;
		}
		e=parseInt(draggeddiv)-1; //back
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			m4[d]=e; //front
			d++;
		}
		for(var i=1;i<8;i++)
		{
			var e;
			e=m1[i-1]+1;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m1[a]=e;
				a++;
			}
			e=m2[i-1]-100;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m2[b]=e; //front
				b++;
			}
			e=m3[i-1]+100;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m3[c]=e; //front
				c++;
			}
			
			e=m4[i-1]-1;
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				m4[d]=e; //front
				d++;
			}
		}
		if(m1.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
			var x="";
				for(var j=0;j<a;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wr1")||(data=="wr2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;		//to break from the other loop
					}
					if(k>0)
					{
						break;
					}
				}
		//		alert("K:" +k);
			//	alert("x" +x);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m1[j]).style.background="grey";
					}
				}
				
				if(!x)
				{
					
					for(var j=0;j<a;j++)		//array length
					{
						document.getElementById(m1[j]).style.background="grey";
					}
				}
		}
		
		if(m2.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
				var x="";
				for(var j=0;j<b;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wr1")||(data=="wr2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;
					}
					if(k>0)
					{
						break;
					}
				}
			//	alert("K:" +k);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m2[j]).style.background="grey";
					}
				}
				if(!x)
				{
					
					for(var j=0;j<b;j++)		//array length
					{
						document.getElementById(m2[j]).style.background="grey";
					}
				}

		}
		
		if(m3.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
				var x="";
				for(var j=0;j<c;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wr1")||(data=="wr2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;
					}
					if(k>0)
					{
						break;
					}
				}
			//	alert("K:" +k);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m3[j]).style.background="grey";
					}
				}
				if(!x)
				{
					
					for(var j=0;j<c;j++)		//array length
					{
						document.getElementById(m3[j]).style.background="grey";
					}
				}
		
		}
		if(m4.length!=0)	
		{
			var img="";
			var k=0;
			var flag=0;
		
				var x="";
				for(var j=0;j<d;j++)		//array length
				{
					for(var i=0;i<imageid.length;i++)
					{
						x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
						if(x)						
						{
							
							img=imageid[i];
						//	alert("img :" +img);
							if((data=="wr1")||(data=="wr2")||(data=="wq1"))
							{
								if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
										(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
								{
									k=j+1;	
									break;
								}
								
							}
							else
							{
								if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
									(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
								{
									k=j+1;	
									break;
								}
							}
							k=j;
							if(j==0)			//piece present at first position
							{
								flag=1;
							}
							break;							//nreak from inner loop
						}
					}
					if(flag==1)
					{
						break;
					}
					if(k>0)
					{
						break;
					}
				}
			//	alert("K:" +k);
				if(k!=0)
				{
					for(var j=0;j<k;j++)		//array length
					{
						document.getElementById(m4[j]).style.background="grey";
					}
				}
				if(!x)
				{
					
					for(var j=0;j<d;j++)		//array length
					{
						document.getElementById(m4[j]).style.background="grey";
					}
				}
		}
	}
}

//**************************************************************************************************************************************
//-----------------------------------------------function for rook move---------------------------------------------------------------
//**************************************************************************************************************************************
function rookmove(data,ev,idd)
{
	var m1=new Array();
	var m2=new Array();
	var m3=new Array();
	var m4=new Array();
	var drop=1;
	var front=0,left=0,right=0,back=0;
	var k;
	
	
	
	if((data=="wr1")||(data=="wr2")||(data=="br1")||(data=="br2"))
	{
		m1[0]=parseInt(draggeddiv)+1; //front 
		m2[0]=parseInt(draggeddiv)-100; //left
		m3[0]=parseInt(draggeddiv)+100; //right
		m4[0]=parseInt(draggeddiv)-1; //back
		for(var i=1;i<8;i++)
		{
			m1[i]=m1[i-1]+1;
			m2[i]=m2[i-1]-100;
			m3[i]=m3[i-1]+100;
			m4[i]=m4[i-1]-1;
		}
		for(var i=0;i<8;i++)
		{
			if(m1[i]==parseInt(idd))
			{
				drop=0;		//can be moved as drop id belong in the rook's path
				front=1;
				k=i+1;
				break;
			}
			if(m2[i]==parseInt(idd))
			{
				drop=0;
				left=1;
				k=i+1;
				break;
			}
			if(m3[i]==parseInt(idd))
			{
				drop=0;
				right=1;
				k=i+1;
				break;
			}
			if(m4[i]==parseInt(idd))
			{
				drop=0;
				back=1;
				k=i+1;
				break;
			}
		}
		if(drop==0)	//---------rook piece can be moved--------
		{
			var pathimg="";
		//	alert("can drop");
		//	alert("K: "+k);
			for(var i=0;i<imageid.length;i++)
			{
				//------------checks for chess piece in the path----------------
				for(var j=0;j<k-1;j++)	//path between draggeddiv and dropzone
				{
					if(front==1)	//front path
					{
						//alert("front path");
						x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
					//	document.getElementById(m1[j]).style.background="grey";
						if(x)						//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					}
					if(left==1)
					{
						//alert("left path");
						x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
						if(x)	//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					
					}
					if(right==1)
					{
						//alert("right path");
						x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
						if(x)	//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					}
					if(back==1)
					{
						//alert("back path");
						x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
						if(x)	//chess piece present in the path
						{
							pathimg=imageid[i];		
							break;
						}
					}
				}
			}
		//	alert("path: "+pathimg)
			if(pathimg!="")	//chess piece present in path
			{
				alert("INVALID MOVE");
				if((data=="wr1")||(data=="wr2")) 	//---------reset turn---------
				{
					document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
					return false;
				}
				else
				{
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
					return false;
				}
			}
			else			//no chess piece in path
			{
				rookcapture(idd,data,ev);
			}
		}
		else
		{
			alert("Invalid Move!!");
			if((data=="wr1")||(data=="wr2")) //---------reset turn---------
			{
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				return false;
			}
			else
			{
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
		}
	}
}
