var path=new Array();
var knightcheckarr=new Array();
function knightcheck(idd,data)
{
	
	var e,x,img;
	e=(parseInt(idd)+2)-100;	//2 steps front and one step left
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[0]=e;
	}
	else
	{
		knightcheckarr[0]=0;
	}
	e=(parseInt(idd)+2)+100;	//--------------//2 steps front and one step right
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[1]=e;
	}
	else
	{
		knightcheckarr[1]=0;
	}
	
	e=(parseInt(idd)+1)-200;	//-------one step front and 2 step left
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[2]=e;
	}
	else
	{
		knightcheckarr[2]=0;
	}
	e=(parseInt(idd)+1)+200;	//-------one step front and 2 step right
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[3]=e;
	}
	else
	{
		knightcheckarr[3]=0;
	}
	
	e=(parseInt(idd)-2)-100;	//2 steps back and one step left
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[4]=e;
	}
	else
	{
		knightcheckarr[4]=0;
	}
	
	e=(parseInt(idd)-2)+100;	//2 steps back and one step right
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[5]=e;
	}
	else
	{
		knightcheckarr[5]=0;
	}
	
	e=(parseInt(idd)-1)-200;	//2 steps front and one step left
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[6]=e;
	}
	else
	{
		knightcheckarr[6]=0;
	}
	
	e=(parseInt(idd)-1)+200;	//--------------//2 steps front and one step right
	x=checkrange(e);
	if(x)
	{
		knightcheckarr[7]=e;
	}
	else
	{
		knightcheckarr[7]=0;
	}
	//alert(knightcheckarr);
	for(var i=0;i<8;i++)		//array length
	{
		if(knightcheckarr[i]!=0)
		{
			if((data=="wn1")||(data=="wn2"))
			{
				//alert(path[i]);
				x=document.getElementById(knightcheckarr[i]).contains(document.getElementById("bk1"));	
				if(x)
				{
					alert("CHECK!!");
					document.getElementById(parseInt(idd)).style.border="2px solid red";
					return "bk1";
				}
			}
			else
			{
				//alert(path[i]);
				x=document.getElementById(knightcheckarr[i]).contains(document.getElementById("wk1"));	
				if(x)
				{
					alert("CHECK!!");
					document.getElementById(parseInt(idd)).style.border="2px solid red";
					return "wk1";
				}
			}
		}
	
	}
}



function knighthighlight(data)
{
	var e,x,img;
	e=(parseInt(draggeddiv)+2)-100;	//2 steps front and one step left
	x=checkrange(e);
	if(x)
	{
		path[0]=e;
	}
	else
	{
		path[0]=0;
	}
	e=(parseInt(draggeddiv)+2)+100;	//--------------//2 steps front and one step right
	x=checkrange(e);
	if(x)
	{
		path[1]=e;
	}
	else
	{
		path[1]=0;
	}
	
	e=(parseInt(draggeddiv)+1)-200;	//-------one step front and 2 step left
	x=checkrange(e);
	if(x)
	{
		path[2]=e;
	}
	else
	{
		path[2]=0;
	}
	e=(parseInt(draggeddiv)+1)+200;	//-------one step front and 2 step right
	x=checkrange(e);
	if(x)
	{
		path[3]=e;
	}
	else
	{
		path[3]=0;
	}
	
	e=(parseInt(draggeddiv)-2)-100;	//2 steps back and one step left
	x=checkrange(e);
	if(x)
	{
		path[4]=e;
	}
	else
	{
		path[4]=0;
	}
	
	e=(parseInt(draggeddiv)-2)+100;	//2 steps back and one step right
	x=checkrange(e);
	if(x)
	{
		path[5]=e;
	}
	else
	{
		path[5]=0;
	}
	
	e=(parseInt(draggeddiv)-1)-200;	//2 steps front and one step left
	x=checkrange(e);
	if(x)
	{
		path[6]=e;
	}
	else
	{
		path[6]=0;
	}
	
	e=(parseInt(draggeddiv)-1)+200;	//--------------//2 steps front and one step right
	x=checkrange(e);
	if(x)
	{
		path[7]=e;
	}
	else
	{
		path[7]=0;
	}
	
	for(var i=0;i<8;i++)		//array length
	{
		if(path[i]!=0)
		{
			if((data=="wn1")||(data=="wn2"))
			{
				for(var j=0;j<imageid.length;j++)
				{
					//alert(path[i]);
					x=document.getElementById(path[i]).contains(document.getElementById(imageid[j]));	
					if(x)
					{
						break;
					}
					
				}
				if(x)	//contains an image
				{
					img=imageid[j];		//image id is stored in variable img
					if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
					(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))
					{
							document.getElementById(path[i]).style.background="grey";
					}
					
				}
				else if(!x)
				{
						//document.getElementById(path[i]).style.background="red";
							document.getElementById(path[i]).style.background="grey";
							
				}
					
			}
			else
			{
				
				for(var j=0;j<imageid.length;j++)
				{
					//alert(path[i]);
					x=document.getElementById(path[i]).contains(document.getElementById(imageid[j]));	
					if(x)
					{
						break;
					}
					
				}
				if(x)	//contains an image
				{
					
					img=imageid[j];		//image id is stored in variable img
					if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
						(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
					{
					
							document.getElementById(path[i]).style.background="grey";
					}
					
				}
				else if(!x)
				{
						//document.getElementById(path[i]).style.background="red";
							document.getElementById(path[i]).style.background="grey";
							
				}
			}
		}
	
	}
}


function checkrange(e)
{
	if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
		(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
	{
			return true;
	}
	else
	{
		return false;
	}
}


function knightmove(data,ev,idd)
{
	var e,x,img,flag=0;
	
	//-----------------checks if dropzone is empty-----------------
	for(var i=0;i<8;i++)
	{
		if(parseInt(idd)==path[i])
		{
			flag=1;
			for(var j=0;j<imageid.length;j++)
			{
				x=document.getElementById(idd).contains(document.getElementById(imageid[j]));	
				if(x)	//contains an image
				{
					img=imageid[j];		//image id is stored in variable img
					break;
				}
			}
		}
		
	}
	if(flag==0)				//drop  id not present in path
	{
	
		if((data=="wn1")||(data=="wn2"))
		{
			alert("Invalid Move!!");
		document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
				turn=0;
			return false;
		}
		
		else
		{
			alert("Invalid Move!!");
			turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
			return false;
		}
	}
	if(x)
	{
		if((data=="wn1")||(data=="wn2"))
		{
			if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
					(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))
			{
					var el = ev.target;
					
					if (!el.classList.contains('dropzone')) 
					{
					   el = ev.target.parentNode;
					 //  alert(el);
					   ev.target.remove();
					    var chk=checkemptydivblack();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
					}
					el.appendChild(document.getElementById(data));
					
						//-------------------------------------checks for illegal move--------------------	
					var t=check();
					if(t=="wk1")
					{
						alert("illegal move!!");
						document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
				turn=0;
						document.getElementById(draggeddiv).appendChild(document.getElementById(data));
						document.getElementById(idtest).appendChild(ev.target);
						
						return false;
					}
					else if(t=="bk1")
					{
						checkmate(t);
					}
			}
			else
			{
				alert("Invalid Move!!");
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
				turn=0;
				return false;
			}
		}
		else if((data=="bn1")||(data=="bn2"))
		{
			if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
					(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
			{
				var el = ev.target;
				if (!el.classList.contains('dropzone')) 
				{
				   el = ev.target.parentNode;
				   ev.target.remove();
				    var chk=checkemptydivwhite();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
				}
				el.appendChild(document.getElementById(data));
				
				//-------------------------------------checks for illegal move--------------------	
				var t=check();
				if(t=="bk1")
				{
					alert("illegal move!!");
					turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
					document.getElementById(draggeddiv).appendChild(document.getElementById(data));
					document.getElementById(idtest).appendChild(ev.target);
					return false;
				}
				else if(t=="wk1")
				{
					checkmate(t);
				}
			}
			else
			{
				alert("Invalid Move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
			
		}
		
	}
	else
	{
		ev.target.appendChild(document.getElementById(data));
		
		//-------------------------------------checks for illegal move--------------------	
		if((data=="wn1")||(data=="wn2"))
		{
			var t=check();
			if(t=="wk1")
			{
				alert("illegal move!!");
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
				turn=0;
				document.getElementById(draggeddiv).appendChild(document.getElementById(data));
				document.getElementById(idtest).appendChild(ev.target);
				
				return false;
			}
			else if(t=="bk1")
			{
				checkmate(t);
			}
		}
		else 
		{
			var t=check();
			if(t=="bk1")
			{
				alert("illegal move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				document.getElementById(draggeddiv).appendChild(document.getElementById(data));
				document.getElementById(idtest).appendChild(ev.target);
				return false;
			}
			else if(t=="wk1")
			{
				checkmate(t);
			}
		}
	}
	knightcheck(idd,data);
}
