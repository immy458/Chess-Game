function checkmate(checkdata)
{
var whitepawns=["wp1","wp2","wp3","wp4","wp5","wp6","wp7","wp8"];
var blackpawns=["bp1","bp2","bp3","bp4","bp5","bp6","bp7","bp8"];
var bbishopqueen=["bb1","bb2","bq1"];
var wbishopqueen=["wb1","wb2","wq1"];
var brookqueen=["br1","br2","bq1"];
var wrookqueen=["wr1","wr2","wq1"];
var bknight=["bn1","bn2"];
var wknight=["wn1","wn2"];
	if(checkdata=="wk1" || checkdata=="bk1")
	{
	//	alert("in checkmate");
		
		var e,x;
		for(var e=101;e<=808;e++)
		{		
			if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
			{
				//alert(e);
				for(var i=0;i<imageid.length;i++)
				{
					x=document.getElementById(parseInt(e)).contains(document.getElementById(checkdata));	
					if(x)
					{
						break;
					}
				}
				if(x)
				{
					break;
				}
			}
		}

		var checkmatearr=new Array();
		var idd=e;
	
		e=parseInt(idd)+1; //front 
		x=checkrange(e);
		if(x)
		{
			checkmatearr[0]=e;
		}
		else
		{
			checkmatearr[0]=0;
		}
		e=parseInt(idd)-100; //left
		x=checkrange(e);
		if(x)
		{
			checkmatearr[1]=e;
		}
		else
		{
			checkmatearr[1]=0;
		}
		e=parseInt(idd)+100; //right
		x=checkrange(e);
		if(x)
		{
			checkmatearr[2]=e;
		}
		else
		{
			checkmatearr[2]=0;
		}
		e=parseInt(idd)-1; //back
		x=checkrange(e);
		if(x)
		{
			checkmatearr[3]=e;
		}
		else
		{
			checkmatearr[3]=0;
		}
		e=parseInt(idd)-99; //to move front diagonally left
		x=checkrange(e);
		if(x)
		{
			checkmatearr[4]=e;
		}
		else
		{
			checkmatearr[4]=0;
		}
		e=parseInt(idd)+99; //to move backwards diagonally left
		x=checkrange(e);
		if(x)
		{
			checkmatearr[5]=e;
		}
		else
		{
			checkmatearr[5]=0;
		}
		e=parseInt(idd)-101; //to move backwards diagonally right
		x=checkrange(e);
		if(x)
		{
			checkmatearr[6]=e;
		}
		else
		{
			checkmatearr[6]=0;
		}
		e=parseInt(idd)+101; //to move front diagonally right
		x=checkrange(e);
		if(x)
		{
			checkmatearr[7]=e;
		}
		else
		{
			checkmatearr[7]=0;
		}
		e=parseInt(idd); //to move front diagonally right
		x=checkrange(e);
		if(x)
		{
			checkmatearr[8]=e;
		}
		else
		{
			checkmatearr[8]=0;
		}
		
		var emptydivs=new Array();
		var a=0;
		var total=0;
		for(var i=0;i<8;i++)
		{
			if(checkmatearr[i]!=0)
			{
				for(var j=0;j<imageid.length;j++)
				{
					//alert(path[i]);
					x=document.getElementById(checkmatearr[i]).contains(document.getElementById(imageid[j]));	
					if(x)
					{
						break;
					}
				}
				if(!x)
				{
					emptydivs[a]=checkmatearr[i];
					a++;
				}
			}
		}
	}
	//alert("checkdata: "+checkdata);
	//alert("checkmatearr:" +checkmatearr);
	//alert("idd: "+idd);
	if(checkdata=="wk1" || checkdata=="bk1")
	{
		
		//alert(emptydivs);
		if(emptydivs.length==0)
		{
				if(checkdata=="wk1")
				{
					alert("CHECKMATE!!! "+bplayer+ " (BLACK) WINS \n THANK YOU!!");
					window.location.href = "mainpage.html";
					return process.exit(1);
				}
				else
				{
					alert("CHECKMATE!!! "+wplayer+ " (WHITE) WINS \n THANK YOU!!");
					window.location.href = "mainpage.html";
					return process.exit(1);
				}
		}
		else
		{
			for(var p=0;p<emptydivs.length;p++)
			{
//-------------------------------------------------------------------rook---------------------------------------------------				
				var m1=new Array();
				var m2=new Array();
				var m3=new Array();
				var m4=new Array();
				var frontking=0,leftking=0,rightking=0,backking=0;
				var x;
				var a=0,b=0,c=0,d=0;
				var pathimg="";
				var k=0;
				var tempflag=0;
				
				var e=parseInt(emptydivs[p])+1; //front	
				if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
				(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
				{
					m1[a]=e;
					a++;
				}
				e=parseInt(emptydivs[p])-100; //left
				if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
					(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
				{
					m2[b]=e; 
					b++;
				}
				e=parseInt(emptydivs[p])+100; //right
				if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
					(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
				{
					m3[c]=e; 
					c++;
				}
				e=parseInt(emptydivs[p])-1; //back
				if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
					(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
				{
					m4[d]=e; //front
					d++;
				}
				for(var i=1;i<8;i++)
				{
					var e;
					e=m1[i-1]+1;
					if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
						(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
					{
						m1[a]=e;
						a++;
					}
					e=m2[i-1]-100;
					if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
						(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
					{
						m2[b]=e; //front
						b++;
					}
					e=m3[i-1]+100;
					if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
					(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
					{
						m3[c]=e; //front
						c++;
					}
					
					e=m4[i-1]-1;
					if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
						(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
					{
						m4[d]=e; //front
						d++;
					}
				}
				if(m1.length!=0)	
				{
					for(var j=0;j<a;j++)
					{
						if(checkdata=="wk1")
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m1[j]).contains(document.getElementById(brookqueen[m]));	
								if(x)						
								{
									frontking=1;	
									k=j+1;			
									break;
								}
							}
						}
						else
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m1[j]).contains(document.getElementById(wrookqueen[m]));	
								if(x)						
								{
									frontking=1;	
									k=j+1;			
									break;
								}
							}
						}
					}
				}
				//alert("m2 length :" +m2.length);
				if(m2.length!=0)
				{
					for(var j=0;j<b;j++)
					{
						if(checkdata=="wk1")
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m2[j]).contains(document.getElementById(brookqueen[m]));	
								if(x)	
								{
									leftking=1;	
									k=j+1;			
									break;
								}
							}
						}
						else
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m2[j]).contains(document.getElementById(wrookqueen[m]));	
								if(x)						
								{
									leftking=1;	
									k=j+1;			
									break;
								}
							}
						}
					}
				}
				if(m3.length!=0)
				{
					for(var j=0;j<c;j++)
					{
						if(checkdata=="wk1")
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m3[j]).contains(document.getElementById(brookqueen[m]));	
								if(x)	
								{
									rightking=1;	
									k=j+1;			
									break;
								}
							}
						}
						else
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m3[j]).contains(document.getElementById(wrookqueen[m]));	
								if(x)						
								{
									rightking=1;	
									k=j+1;			
									break;
								}
							}
						}
					}
				}
				if(m4.length!=0)
				{
					for(var j=0;j<d;j++)
					{
						if(checkdata=="wk1")
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m4[j]).contains(document.getElementById(brookqueen[m]));	
								if(x)	
								{
									backking=1;	
									k=j+1;			
									break;
								}
							}
						}
						else
						{
							for(var m=0;m<3;m++)
							{
								x=document.getElementById(m4[j]).contains(document.getElementById(wrookqueen[m]));	
								if(x)						
								{
									backking=1;	
									k=j+1;			
									break;
								}
							}
						}
					}
				}
				if(k>0)	
				{
					for(var i=0;i<imageid.length;i++)
					{
						//------------checks for any chess piece in between rook and emptydivs---------------
							
								if(frontking==1)	//front path
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
										if(x)						//chess piece present in the path
										{
											pathimg=imageid[i];		
											tempflag=1;
											break;
										}
									}
								}
								if(leftking==1)
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
										if(x)	//chess piece present in the path
										{
											pathimg=imageid[i];	
											tempflag=1;
											break;
										}
									}
								}
								if(rightking==1)
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
										if(x)	//chess piece present in the path
										{
											pathimg=imageid[i];	
											tempflag=1;
											break;
										}
									}
								}
								if(backking==1)
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
										if(x)	//chess piece present in the path
										{
											pathimg=imageid[i];	
											tempflag=1;
											break;
										}
									}
								}
							
					}
					if((pathimg=="")&&(tempflag==0))	// no chess piece present in between rook and empty div
					{
						total=total+1;
						//document.getElementById(parseInt(idd)).style.border="2px solid red";
					}
					
				}
			//	alert("rookfinished");
//-------------------------------------------------knightcheck----------------------------------------------------------------------------
				/*var q=knightcheck(emptydivs[p],"bn1");
				var r=knightcheck(emptydivs[p],"bn2");
				if(q)
				{
					total=total+1;
				}
				if(r)
				{
					total=total+1;
				}
				alert("knightfinished");*/
				
				var e,x,img;
				e=(parseInt(emptydivs[p])+2)-100;	//2 steps front and one step left
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[0]=e;
				}
				else
				{
					knightcheckarr[0]=0;
				}
				e=(parseInt(emptydivs[p])+2)+100;	//--------------//2 steps front and one step right
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[1]=e;
				}
				else
				{
					knightcheckarr[1]=0;
				}
				
				e=(parseInt(emptydivs[p])+1)-200;	//-------one step front and 2 step left
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[2]=e;
				}
				else
				{
					knightcheckarr[2]=0;
				}
				e=(parseInt(emptydivs[p])+1)+200;	//-------one step front and 2 step right
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[3]=e;
				}
				else
				{
					knightcheckarr[3]=0;
				}
				
				e=(parseInt(emptydivs[p])-2)-100;	//2 steps back and one step left
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[4]=e;
				}
				else
				{
					knightcheckarr[4]=0;
				}
				
				e=(parseInt(emptydivs[p])-2)+100;	//2 steps back and one step right
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[5]=e;
				}
				else
				{
					knightcheckarr[5]=0;
				}
				
				e=(parseInt(emptydivs[p])-1)-200;	//2 steps front and one step left
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[6]=e;
				}
				else
				{
					knightcheckarr[6]=0;
				}
				
				e=(parseInt(emptydivs[p])-1)+200;	//--------------//2 steps front and one step right
				x=checkrange(e);
				if(x)
				{
					knightcheckarr[7]=e;
				}
				else
				{
					knightcheckarr[7]=0;
				}
		//		alert(knightcheckarr);
				for(var i=0;i<8;i++)		//array length
				{
					if(knightcheckarr[i]!=0)
					{
						if(checkdata=="wk1")
						{
							for(var k=0;k<2;k++)
							{
								x=document.getElementById(knightcheckarr[i]).contains(document.getElementById(bknight[k]));	
								if(x)
								{
									break;
								}
							}
							if(x)
							{
								total=total+1;
								break;
							}
						}
						else
						{
							for(var k=0;k<2;k++)
							{
								x=document.getElementById(knightcheckarr[i]).contains(document.getElementById(wknight[k]));	
								if(x)
								{
									break;
								}
							}
							if(x)
							{
								total=total+1;
								break;
							}
						}
					}
				}
		//		alert("knightfinished");
//--------------------------------------------------------------pawn------------------------------------------------------------------------
				var rd,ld;
				if(checkdata=="wk1")
				{
					rd=parseInt(emptydivs[p])-99;	
					ld=parseInt(emptydivs[p])+101;
				}
				else
				{
					rd=parseInt(emptydivs[p])+99;	
					ld=parseInt(emptydivs[p])-101;
				}
				var x,y;
				for(var k=0;k<8;k++)
				{
					if((rd>=101 && rd<=108)||(rd>=201 && rd<=208)||(rd>=301 && rd<=308)||(rd>=401 && rd<=408)||
						(rd>=501 && rd<=508)||(rd>=601 && rd<=608)||(rd>=701 && rd<=708)||(rd>=801 && rd<=808))
					{
						if(checkdata=="wk1")
						{
							x=document.getElementById(rd).contains(document.getElementById(blackpawns[k]));
						}
						else
						{
							x=document.getElementById(rd).contains(document.getElementById(whitepawns[k]));
						}
					}
					if((ld>=101 && ld<=108)||(ld>=201 && ld<=208)||(ld>=301 && ld<=308)||(ld>=401 && ld<=408)||
					(ld>=501 && ld<=508)||(ld>=601 && ld<=608)||(ld>=701 && ld<=708)||(ld>=801 && ld<=808))
					{
						if(checkdata=="wk1")
						{
							y=document.getElementById(ld).contains(document.getElementById(blackpawns[k]));
						}
						else
						{
							y=document.getElementById(ld).contains(document.getElementById(whitepawns[k]));
						}
					}
					if(x)	//contains an image
					{
						break;
					}
					if(y)
					{
						break;
					}
				}
				if((x) || (y))
				{	
					total=total+1;
				}
		//		alert("pawnfinished");
				
//---------------------------------------------------------------bishop-------------------------------------------------------------------
				var m1=new Array();
				var m2=new Array();
				var m3=new Array();
				var m4=new Array();		
				var leftfrontking=0,leftbackking=0,rightbackking=0,rightfrontking=0;
				var x;
				var pathimg="";
				var k=0;
				var tempflag=0;
				var a=0,b=0,c=0,d=0,e;		
				e=parseInt(emptydivs[p])-99; //to move front diagonally left
				
				x=checkrange(e);
				if(x)
				{
					m1[a]=e;
					a++;
				}
				e=parseInt(emptydivs[p])+99; //to move backwards diagonally left
				x=checkrange(e);
				if(x)
				{
					m2[b]=e;
					b++;
				}
				e=parseInt(emptydivs[p])-101; //to move backwards diagonally right
				x=checkrange(e);
				if(x)
				{
					m3[c]=e;
					c++;
				}
				e=parseInt(emptydivs[p])+101; //to move front diagonally right
				x=checkrange(e);
				if(x)
				{
					m4[d]=e;
					d++;
				}
			
				for(var i=1;i<8;i++)
				{
					var e;
					e=m1[i-1]-99;
					x=checkrange(e);
					if(x)
					{
						m1[a]=e;
						a++;
					}
					e=m2[i-1]+99;
					x=checkrange(e);
					if(x)
					{
						m2[b]=e;
						b++;
					}
					e=m3[i-1]-101;
					x=checkrange(e);
					if(x)
					{
						m3[c]=e;
						c++;
					}
					e=m4[i-1]+101;
					x=checkrange(e);
					if(x)
					{
						m4[d]=e;
						d++;
					}
				}
				if(m1.length!=0)	
				{
					var x;
					for(var j=0;j<a;j++)
					{
						//------checks if bishop piece is present in ids present in array m1---
						for(var m=0;m<3;m++)
						{
							if(checkdata=="wk1")
							{
								x=document.getElementById(m1[j]).contains(document.getElementById(bbishopqueen[m]));	
								if(x)						
								{
									leftfrontking=1;	
									k=j+1;		
									break;
								}
							}
							else
							{
								x=document.getElementById(m1[j]).contains(document.getElementById(wbishopqueen[m]));	
								if(x)						
								{
									leftfrontking=1;	
									k=j+1;		
									break;
								}
							}
						}
					}
				}
				if(m2.length!=0)
				{
					var x;
					for(var j=0;j<b;j++)
					{
						for(var m=0;m<3;m++)
						{
							if(checkdata=="wk1")
							{
								x=document.getElementById(m2[j]).contains(document.getElementById(bbishopqueen[m]));	
								if(x)	
								{
									leftbackking=1;
									k=j+1;			
									break;
								}
							}
							else
							{
								x=document.getElementById(m2[j]).contains(document.getElementById(wbishopqueen[m]));	
								if(x)	
								{
									leftbackking=1;
									k=j+1;			
									break;
								}
							}
						}
					}
				}
				if(m3.length!=0)
				{
					var x;
					for(var j=0;j<c;j++)
					{
						for(var m=0;m<3;m++)
						{
							if(checkdata=="wk1")
							{
								x=document.getElementById(m3[j]).contains(document.getElementById(bbishopqueen[m]));	
								if(x)	
								{
									rightbackking=1;	
									k=j+1;			
									break;
								}	
							}
							else
							{
								x=document.getElementById(m3[j]).contains(document.getElementById(wbishopqueen[m]));	
								if(x)	
								{
									rightbackking=1;	
									k=j+1;			
									break;
								}
							}
						}
					}
				}
				if(m4.length!=0)
				{
					
					var x;
					for(var j=0;j<d;j++)
					{
						for(var m=0;m<3;m++)
						{
							if(checkdata=="wk1")
							{
								x=document.getElementById(m4[j]).contains(document.getElementById(bbishopqueen[m]));	
								if(x)	
								{
									rightfrontking=1;	
									k=j+1;			
									break;
								}
							}
							else
							{
								x=document.getElementById(m4[j]).contains(document.getElementById(wbishopqueen[m]));	
								if(x)	
								{
									rightfrontking=1;	
									k=j+1;			
									break;
								}
							}
						}
					}
				}
			//	alert("k:"+k);
				if(k>0)	//------------king present in the path----------
				{
					for(var i=0;i<imageid.length;i++)
					{
						//------------checks for any chess piece in between bishop and empty div---------------
							
								if(leftfrontking==1)	//front path
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m1[j]).contains(document.getElementById(imageid[i]));	
										if(x)						//chess piece present in the path
										{
											pathimg=imageid[i];		
											tempflag=1;
											break;
										}
									}
								}
								if(leftbackking==1)
								{
									
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m2[j]).contains(document.getElementById(imageid[i]));	
										if(x)	//chess piece present in the path
										{
											pathimg=imageid[i];	
											tempflag=1;
											break;
										}
									}
								}
								if(rightbackking==1)
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m3[j]).contains(document.getElementById(imageid[i]));	
										if(x)	//chess piece present in the path
										{
											pathimg=imageid[i];	
											tempflag=1;
											break;
										}
									}
								}
								if(rightfrontking==1)
								{
									for(var j=0;j<k-1;j++)	
									{
										x=document.getElementById(m4[j]).contains(document.getElementById(imageid[i]));	
										if(x)	//chess piece present in the path
										{
											pathimg=imageid[i];	
											tempflag=1;
											break;
										}
									}
								}
							
					}
					
					if((pathimg=="")&&(tempflag==0))	//no chess piece between empty div and bishop
					{
						total=total+1;
					}
			//		alert("bishopcheckfinished");
				}
			
				
//-----------------------------------------------king------------------------------------------------------------------------------------------
					/*var q=kingcheck("bk1",emptydivs[p]);			//1checks
					if(q)
					{
						total=total+1;
					}
						alert("kingfinished");*/
						
						
					var kingcheckarr=new Array();
					var e;
					e=parseInt(emptydivs[p])+1; //front 
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[0]=e;
					}
					else
					{
						kingcheckarr[0]=0;
					}
					e=parseInt(emptydivs[p])-100; //left
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[1]=e;
					}
					else
					{
						kingcheckarr[1]=0;
					}
					e=parseInt(emptydivs[p])+100; //right
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[2]=e;
					}
					else
					{
						kingcheckarr[2]=0;
					}
					e=parseInt(emptydivs[p])-1; //back
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[3]=e;
					}
					else
					{
						kingcheckarr[3]=0;
					}
					e=parseInt(emptydivs[p])-99; //to move front diagonally left
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[4]=e;
					}
					else
					{
						kingcheckarr[4]=0;
					}
					e=parseInt(emptydivs[p])+99; //to move backwards diagonally left
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[5]=e;
					}
					else
					{
						kingcheckarr[5]=0;
					}
					e=parseInt(emptydivs[p])-101; //to move backwards diagonally right
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[6]=e;
					}
					else
					{
						kingcheckarr[6]=0;
					}
					e=parseInt(emptydivs[p])+101; //to move front diagonally right
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[7]=e;
					}
					else
					{
						kingcheckarr[7]=0;
					}
					e=parseInt(emptydivs[p]); 
					x=checkrange(e);
					if(x)
					{
						kingcheckarr[8]=e;
					}
					else
					{
						kingcheckarr[8]=0;
					}
					for(var i=0;i<9;i++)		//array length
					{
						if(kingcheckarr[i]!=0)
						{
							if((checkdata=="wk1"))
							{
								//alert(path[i]);
								x=document.getElementById(kingcheckarr[i]).contains(document.getElementById("bk1"));	
								if(x)
								{
									total=total+1;
									break;
								}
							}
							else
							{
								//alert(path[i]);
								x=document.getElementById(kingcheckarr[i]).contains(document.getElementById("wk1"));	
								if(x)
								{
									total=total+1;
									break;
								}
							}
						}
					
					}
				//	alert(kingcheckarr);
					
			}
				
	//		alert("emptydivslength: "+emptydivs.length);
		//	alert("total: "+total);
			if(total==emptydivs.length)
			{
				if(checkdata=="wk1")
				{
					alert("CHECKMATE!!! "+bplayer+ " (BLACK) WINS \n THANK YOU!!");	
					window.location.href = "mainpage.html";
					return process.exit(1);
				}
				else
				{
					alert("CHECKMATE!!! "+wplayer+ " (WHITE) WINS \n THANK YOU!!");
					window.location.href = "mainpage.html";
					return process.exit(1);
				}
			}
		}
	}
		
}
