//alert("hello");
var moved="false";
var draggeddiv;
var timepass;
var img;
var x="false";			
var imageid=["wp1","wp2","wp3","wp4","wp5","wp6","wp7","wp8","wr1","wn1","wb1","wq1","wk1","wb2","wn2","wr2","bp1","bp2","bp3","bp4","bp5","bp6","bp7","bp8","br1","bn1","bb1","bq1","bk1","bb2","bn2","br2"];


var movetrack=new Array();
var k=0;
var turn=0;
var lightturn=0;
var highlightdata="";
var idtest;

var checkdata;	//for checkmate
var checkid;


var imported = document.createElement('script');
imported.src = 'rookmove.js';
document.head.appendChild(imported);

var imported1 = document.createElement('script');
imported1.src = 'pawn.js';
document.head.appendChild(imported1);

var imported2 = document.createElement('script');
imported2.src = 'knight.js';
document.head.appendChild(imported2);

var imported3 = document.createElement('script');
imported3.src = 'bishop.js';
document.head.appendChild(imported3);

var imported4 = document.createElement('script');
imported4.src = 'queen.js';
document.head.appendChild(imported4);

var imported5 = document.createElement('script');
imported5.src = 'check.js';
document.head.appendChild(imported5);

var imported6 = document.createElement('script');
imported6.src = 'king.js';
document.head.appendChild(imported6);

var imported7 = document.createElement('script');
imported7.src = 'checkmate.js';
document.head.appendChild(imported7);

var submitted=0;
var wplayer="";
var bplayer="";
function getParameterByName(name) {
    var url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
	
}


var wplayer = getParameterByName("player1name");
var bplayer = getParameterByName("player2name");
document.getElementById("bturn1").innerHTML="";
document.getElementById("bturn2").innerHTML="";
document.getElementById("wturn1").innerHTML="YOUR";
document.getElementById("wturn2").innerHTML="TURN";
alert("yes");
//alert("hello: "+wplayer);
//alert("hello: "+bplayer);

//-----------------------------------------------checkemptydiv to put opponent piece in div----------------------------------------------------
	function checkemptydivblack()
	{
	//	alert("hey");
		for(var g=2000;g<=2015;g++)
		{
			
				for(var h=0;h<imageid.length;h++)
				{
					//alert(path[i]);
					var x=document.getElementById(g).contains(document.getElementById(imageid[h]));	
					//alert(x);
					if(x)
					{
						
						break;
					}
				}
				if(!x)
				{
					return g;
				}
			
		}
		return 0;
	}

//-----------------------------------------------checkemptydiv to put opponent piece in div----------------------------------------------------
	function checkemptydivwhite()
	{
		
		for(var g=1011;g<=1026;g++)
		{
				//alert(g);
				for(var h=0;h<imageid.length;h++)
				{
					//alert(path[i]);
					var x=document.getElementById(g).contains(document.getElementById(imageid[h]));	
					//alert(x);
					if(x)
					{
						
						break;
					}
				}
				if(!x)
				{
					return g;
				}
		}
		return 0;
	}	
//---------------------------------------------------checks the turn ------------------------------------------
	
		function checkturn(data)
		{
			if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
			{
				if(turn==0)
				{
					turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
					return true;
				}
				else{
					alert(bplayer+"'s (Black) Turn!!");
					return false;
				}
			}
			else if((data=="bp1")||(data=="bp2")||(data=="bp3")||(data=="bp4")||(data=="bp5")||(data=="bp6")||(data=="bp7")||(data=="bp8")||(data=="br1")||(data=="bn1")||(data=="bb1")||(data=="bq1")||(data=="bk1")||(data=="bb2")||(data=="bn2")||(data=="br2"))
			{
				//alert("black");
				
				if(turn==1)
				{
					document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
					return true;
				}
				else{
					
					alert(wplayer+"'s (White) Turn!!");
					return false;
				}
			}
		}

		//-------------------------------------------------------------------------------------------------------------------------------

		function click1(id){		//onmouseover function is used to fetch the id of the div which is dragged and highlights the divs the piece can move
			draggeddiv=parseInt(id);
			for(var e=101;e<=808;e++)	//reset highlighted divs
			{
				if((e>=101 && e<=108)||(e>=301 && e<=308)||(e>=501 && e<=508)||(e>=701 && e<=708))
				{
			
					if(e % 2 == 0)
					{
						document.getElementById(e).style.background="#B1E4B8";
					}
					else 
					{		
							document.getElementById(e).style.background="#70A2A3";
					}
					document.getElementById(e).style.boxShadow="0px 0px 0px 0px grey inset";	
				}
				if((e>=201 && e<=208)||(e>=401 && e<=408)||(e>=601 && e<=608)||(e>=801 && e<=808))
				{
					if(e % 2 == 0)
					{
						document.getElementById(e).style.background="#70A2A3";	
					}
					else 
					{
						document.getElementById(e).style.background="#B1E4B8";
					}
					document.getElementById(e).style.boxShadow="0px 0px 0px 0px grey inset";
				}
			}
				
			for(var i=0;i<imageid.length;i++)
			{
				var x="";
				highlightdata="";			
				x=document.getElementById(draggeddiv).contains(document.getElementById(imageid[i]));	
				if(x)	//gets image id present in the div
				{
					highlightdata=imageid[i];		
					break;
				}
			}

			//----------------rook----------------------
			if((highlightdata=="wr1")||(highlightdata=="wr2")||(highlightdata=="br1")||(highlightdata=="br2"))
			{
				if(turn==0 && ((highlightdata=="wr1")||(highlightdata=="wr2")))
				{
					
					rookhighlight(draggeddiv,highlightdata);
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
				}
				else if (turn==1 && ((highlightdata=="br1")||(highlightdata=="br2")))
				{
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
					rookhighlight(draggeddiv,highlightdata);
				}
			}
			//---------------------pawn------------------------------
			else if((highlightdata=="wp1")||(highlightdata=="wp2")||(highlightdata=="wp3")||(highlightdata=="wp4")||(highlightdata=="wp5")||(highlightdata=="wp6")||(highlightdata=="wp7")||(highlightdata=="wp8")||
				(highlightdata=="bp1")||(highlightdata=="bp2")||(highlightdata=="bp3")||(highlightdata=="bp4")||(highlightdata=="bp5")||(highlightdata=="bp6")||(highlightdata=="bp7")||(highlightdata=="bp8"))
			{
				
				
				if(turn==0 && ((highlightdata=="wp1")||(highlightdata=="wp2")||(highlightdata=="wp3")||(highlightdata=="wp4")||(highlightdata=="wp5")||(highlightdata=="wp6")||(highlightdata=="wp7")||(highlightdata=="wp8")))	//checks if white pawn)
				{
					pawnhighlight(draggeddiv,highlightdata);
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";			
				}
				else if(turn==1 && ((highlightdata=="bp1")||(highlightdata=="bp2")||(highlightdata=="bp3")||(highlightdata=="bp4")||(highlightdata=="bp5")||(highlightdata=="bp6")||(highlightdata=="bp7")||(highlightdata=="bp8")))	//checks if white pawn)
				{
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";	
					pawnhighlight(draggeddiv,highlightdata);			
				}
			}
			//----------------------------------------knight highlight-----------------------------
			else if((highlightdata=="wn1")||(highlightdata=="wn2")||(highlightdata=="bn1")||(highlightdata=="bn2"))
			{	
				if(turn==0 && ((highlightdata=="wn1")||(highlightdata=="wn2")))	//checks if white pawn)
				{
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
					knighthighlight(highlightdata);			
				}
				else if (turn==1 && ((highlightdata=="bn1")||(highlightdata=="bn2")))
				{
					knighthighlight(highlightdata);			
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
				}
			}
			//----------------------------------------bishop  highlight-----------------------------
			else if((highlightdata=="wb1")||(highlightdata=="wb2")||(highlightdata=="bb1")||(highlightdata=="bb2"))
			{	
				if(turn==0 && ((highlightdata=="wb1")||(highlightdata=="wb2")))	
				{
					bishophighlight(highlightdata);				
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
				}
				else if (turn==1 && ((highlightdata=="bb1")||(highlightdata=="bb2")))
				{
					bishophighlight(highlightdata);				
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
				}
			}
			else if ((highlightdata=="wq1")||(highlightdata=="bq1"))
			{
				if(turn==0 && ((highlightdata=="wq1")))	
				{
					bishophighlight(highlightdata);		
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
					rookhighlight(draggeddiv,highlightdata);				
				}
				else if (turn==1 && ((highlightdata=="bq1")))
				{
					bishophighlight(highlightdata);	
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
					rookhighlight(draggeddiv,highlightdata);				
				}
			}
			else if ((highlightdata=="wk1")||(highlightdata=="bk1"))
			{
				if(turn==0 && ((highlightdata=="wk1")))	
				{
					kinghighlight(highlightdata);					
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
				}
				else if (turn==1 && ((highlightdata=="bk1")))
				{
					kinghighlight(highlightdata);						
					document.getElementById(parseInt(draggeddiv)).style.boxShadow="2px 2px 5px 5px grey inset";
				}
			}
			//}
		}
		function allowDrop(ev,idd) {

		  ev.preventDefault();
		//  document.getElementById(idd).style.border="2px solid black";
		}

		function drag(ev) {
			
			ev.dataTransfer.setData("text", ev.target.id);  
			
		}





		function drop(ev,idd) {
			//---------------------------------reset highlighted divs------------------------------------
			idtest=parseInt(idd);
			for(var e=101;e<=808;e++)
			{
				if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
					(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
				{
					document.getElementById(e).style.border="1px solid black";
				}
			}
			ev.preventDefault();
			var data = ev.dataTransfer.getData("text");
			
			var yy=checkturn(data);		//checks turn 
			//checkdrop(data,idd);	//checks drop
			if(!yy)
			{
				return false;
			}
			else
			{	
				
				if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||
				(data=="bp1")||(data=="bp2")||(data=="bp3")||(data=="bp4")||(data=="bp5")||(data=="bp6")||(data=="bp7")||(data=="bp8"))
				{
					pawnmove(data,ev,idd);
				}
				else if((data=="wr1")||(data=="wr2")||(data=="br1")||(data=="br2"))
				{
					rookmove(data,ev,idd);
				}
				else if((data=="wn1")||(data=="wn2")||(data=="bn1")||(data=="bn2"))
				{
					 knightmove(data,ev,idd);
					 
					 
				}
				else if((data=="wb1")||(data=="wb2")||(data=="bb1")||(data=="bb2"))
				{
					bishopmove(data,ev,idd);
					
					
				}
				else if((data=="wq1")||(data=="bq1"))
				{
					queenmove(data,ev,idd);
				}
				else if((data=="wk1")||(data=="bk1"))
				{
					kingmove(data,ev,idd);
				}
				
			}
		
		}
	
	
