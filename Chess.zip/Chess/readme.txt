1) Drag and drop technique used
2)Browser-google chrome,Version-71.0.3578.98
3) Works pefectly in resolution:1600 x 800
4) Run the mainpage.html not the game.html
5) Working features:
	a)Checks for invalid Moves of chess piece
	b)Checks for illegal moves during check
	c)Checks for users turn
	d)Checks if a player makes any move that places or leaves their king in check.(illegal move) 
	e)Check,checkmate
