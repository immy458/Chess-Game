function kingcheck(data,idd){
	var kingcheckarr=new Array();
	var e;
	
	e=parseInt(idd)+1; //front 
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[0]=e;
	}
	else
	{
		kingcheckarr[0]=0;
	}
	e=parseInt(idd)-100; //left
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[1]=e;
	}
	else
	{
		kingcheckarr[1]=0;
	}
	e=parseInt(idd)+100; //right
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[2]=e;
	}
	else
	{
		kingcheckarr[2]=0;
	}
	e=parseInt(idd)-1; //back
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[3]=e;
	}
	else
	{
		kingcheckarr[3]=0;
	}
	e=parseInt(idd)-99; //to move front diagonally left
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[4]=e;
	}
	else
	{
		kingcheckarr[4]=0;
	}
	e=parseInt(idd)+99; //to move backwards diagonally left
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[5]=e;
	}
	else
	{
		kingcheckarr[5]=0;
	}
	e=parseInt(idd)-101; //to move backwards diagonally right
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[6]=e;
	}
	else
	{
		kingcheckarr[6]=0;
	}
	e=parseInt(idd)+101; //to move front diagonally right
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[7]=e;
	}
	else
	{
		kingcheckarr[7]=0;
	}
	e=parseInt(idd); 
	x=checkrange(e);
	if(x)
	{
		kingcheckarr[8]=e;
	}
	else
	{
		kingcheckarr[8]=0;
	}
	for(var i=0;i<9;i++)		//array length
	{
		if(kingcheckarr[i]!=0)
		{
			if((data=="wk1"))
			{
				//alert(path[i]);
				x=document.getElementById(kingcheckarr[i]).contains(document.getElementById("bk1"));	
				if(x)
				{
					alert("CHECK!!");
					document.getElementById(parseInt(idd)).style.border="2px solid red";
					return "bk1";
				}
			}
			else
			{
				//alert(path[i]);
				x=document.getElementById(kingcheckarr[i]).contains(document.getElementById("wk1"));	
				if(x)
				{
					alert("CHECK!!");
					document.getElementById(parseInt(idd)).style.border="2px solid red";
					return "wk1";
				}
			}
		}
	
	}
}
function kinghighlight(data){
	var m1=new Array();
	var e;
	
	e=parseInt(draggeddiv)+1; //front 
	x=checkrange(e);
	if(x)
	{
		m1[0]=e;
	}
	else
	{
		m1[0]=0;
	}
	e=parseInt(draggeddiv)-100; //left
	x=checkrange(e);
	if(x)
	{
		m1[1]=e;
	}
	else
	{
		m1[1]=0;
	}
	e=parseInt(draggeddiv)+100; //right
	x=checkrange(e);
	if(x)
	{
		m1[2]=e;
	}
	else
	{
		m1[2]=0;
	}
	e=parseInt(draggeddiv)-1; //back
	x=checkrange(e);
	if(x)
	{
		m1[3]=e;
	}
	else
	{
		m1[3]=0;
	}
	e=parseInt(draggeddiv)-99; //to move front diagonally left
	x=checkrange(e);
	if(x)
	{
		m1[4]=e;
	}
	else
	{
		m1[4]=0;
	}
	e=parseInt(draggeddiv)+99; //to move backwards diagonally left
	x=checkrange(e);
	if(x)
	{
		m1[5]=e;
	}
	else
	{
		m1[5]=0;
	}
	e=parseInt(draggeddiv)-101; //to move backwards diagonally right
	x=checkrange(e);
	if(x)
	{
		m1[6]=e;
	}
	else
	{
		m1[6]=0;
	}
	e=parseInt(draggeddiv)+101; //to move front diagonally right
	x=checkrange(e);
	if(x)
	{
		m1[7]=e;
	}
	else
	{
		m1[7]=0;
	}
	for(var i=0;i<8;i++)		//array length
	{
		if(m1[i]!="")
		{
			if((data=="wk1"))
			{
				for(var j=0;j<imageid.length;j++)
				{
					//alert(path[i]);
					x=document.getElementById(m1[i]).contains(document.getElementById(imageid[j]));	
					if(x)
					{
						break;
					}
					
				}
				if(x)	//contains an image
				{
					img=imageid[j];		//image id is stored in variable img
					if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
					(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))
					{
							document.getElementById(m1[i]).style.background="grey";
					}
					
				}
				else if(!x)
				{
						//document.getElementById(path[i]).style.background="red";
							document.getElementById(m1[i]).style.background="grey";
							
				}
					
			}
			else
			{
				
				for(var j=0;j<imageid.length;j++)
				{
					//alert(path[i]);
					x=document.getElementById(m1[i]).contains(document.getElementById(imageid[j]));	
					if(x)
					{
						break;
					}
					
				}
				if(x)	//contains an image
				{
					
					img=imageid[j];		//image id is stored in variable img
					if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
						(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
					{
					
							document.getElementById(m1[i]).style.background="grey";
					}
					
				}
				else if(!x)
				{
						//document.getElementById(path[i]).style.background="red";
							document.getElementById(m1[i]).style.background="grey";
							
				}
			}
		}
	
	}

}
function kingmove(data,ev,idd){
	var m1=new Array();
	var e;
	var drop=1;
	if((data=="wk1")||(data=="bk1"))
	{
		e=parseInt(draggeddiv)+1; //front 
		x=checkrange(e);
		if(x)
		{
			m1[0]=e;
		}
		e=parseInt(draggeddiv)-100; //left
		x=checkrange(e);
		if(x)
		{
			m1[1]=e;
		}
		e=parseInt(draggeddiv)+100; //right
		x=checkrange(e);
		if(x)
		{
			m1[2]=e;
		}
		e=parseInt(draggeddiv)-1; //back
		x=checkrange(e);
		if(x)
		{
			m1[3]=e;
		}
		e=parseInt(draggeddiv)-99; //to move front diagonally left
		x=checkrange(e);
		if(x)
		{
			m1[4]=e;
		}
		e=parseInt(draggeddiv)+99; //to move backwards diagonally left
		x=checkrange(e);
		if(x)
		{
			m1[5]=e;
		}
		e=parseInt(draggeddiv)-101; //to move backwards diagonally right
		x=checkrange(e);
		if(x)
		{
			m1[6]=e;
		}
		e=parseInt(draggeddiv)+101; //to move front diagonally right
		x=checkrange(e);
		if(x)
		{
			m1[7]=e;
		}
		for(var i=0;i<8;i++)
		{
			if(m1[i]==parseInt(idd))
			{
				drop=0;		//can be moved as drop id belong in the king's path
				break;
			}
		}
	
		
		if(drop==0)	//can be moved
		{
			//-----------------checks if dropzone is empty-----------------
			for(var i=0;i<8;i++)
			{
				if(parseInt(idd)==m1[i])
				{
					
					for(var j=0;j<imageid.length;j++)
					{
						x=document.getElementById(idd).contains(document.getElementById(imageid[j]));	
						if(x)	//contains an image
						{
							img=imageid[j];		//image id is stored in variable img
							break;
						}
					}
				}
				
			}
			
			if(x)
			{
				if((data=="wk1"))
				{
					if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
							(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))
					{
							var el = ev.target;
							
							if (!el.classList.contains('dropzone')) 
							{
							   el = ev.target.parentNode;
							 //  alert(el);
							   ev.target.remove();
							    var chk=checkemptydivblack();
					  // alert("le"+chk);
							   if(chk!=0)
							   {
									document.getElementById(chk).appendChild(ev.target);
							   }
							}
							el.appendChild(document.getElementById(data));
							
								//-------------------------------------checks for illegal move--------------------	
							var t=check();
							if(t=="wk1")
							{
								alert("illegal move!!");
								document.getElementById("bturn1").innerHTML="";
								document.getElementById("bturn2").innerHTML="";
									document.getElementById("wturn1").innerHTML="YOUR";
								document.getElementById("wturn2").innerHTML="TURN";
								turn=0;
								document.getElementById(draggeddiv).appendChild(document.getElementById(data));
								document.getElementById(idtest).appendChild(ev.target);
								
								return false;
							}
							else if(t=="bk1")
							{
								checkmate(t);
							}
					}
					else
					{
						alert("Invalid Move!!");
						document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
						return false;
					}
				}
				else if((data=="bk1"))
				{
					if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
							(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
					{
						var el = ev.target;
						if (!el.classList.contains('dropzone')) 
						{
						   el = ev.target.parentNode;
						   ev.target.remove();
						    var chk=checkemptydivwhite();
					  // alert("le"+chk);
						   if(chk!=0)
						   {
								document.getElementById(chk).appendChild(ev.target);
						   }
						}
						el.appendChild(document.getElementById(data));
						
						//-------------------------------------checks for illegal move--------------------	
						var t=check();
						if(t=="bk1")
						{
							alert("illegal move!!");
							turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
							document.getElementById(draggeddiv).appendChild(document.getElementById(data));
							document.getElementById(idtest).appendChild(ev.target);
							return false;
						}
						else if(t=="wk1")
						{
							checkmate(t);
						}
					}
					else
					{
						alert("Invalid Move!!");
						turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
						return false;
					}
					
				}
				
			}
			else
			{
				ev.target.appendChild(document.getElementById(data));
				
				//-------------------------------------checks for illegal move--------------------	
				if((data=="wk1"))
				{
					var t=check();
					if(t=="wk1")
					{
						alert("illegal move!!");
						document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
						document.getElementById(draggeddiv).appendChild(document.getElementById(data));
						document.getElementById(idtest).appendChild(ev.target);
						
						return false;
					}
					else if(t=="bk1")
					{
						checkmate(t);
					}
				}
				else 
				{
					var t=check();
					if(t=="bk1")
					{
						alert("illegal move!!");
						turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
						document.getElementById(draggeddiv).appendChild(document.getElementById(data));
						document.getElementById(idtest).appendChild(ev.target);
						return false;
					}
					else if(t=="wk1")
					{
						checkmate(t);
					}
				}
			}
		}
		else
		{
			if((data=="wk1"))
			{
				alert("Invalid Move!!");
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
					turn=0;
				return false;
			}
			else
			{
				alert("Invalid Move!!");
			turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
		}
	}
	kingcheck(idd,data);
}
