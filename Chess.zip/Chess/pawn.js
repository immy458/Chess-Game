function pawnhighlight(draggeddiv,data)
{

	var x,y,z,w;
	var q;
	var path =new Array();
	var img;
	if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8"))
	{
		
		path[0]=parseInt(draggeddiv)+1;	//---------to move one step infront
		q=checkrange(path[0]);
		if(!q)
		{
			path[0]=0;
		}
		path[1]=parseInt(draggeddiv)+2;	//--------------to move two steps infront
		q=checkrange(path[1]);
		if(!q)
		{
			path[1]=0;
		}
		path[2]=parseInt(draggeddiv)+101;	//-------to move one step diagonally right
		q=checkrange(path[2]);
		if(!q)
		{
			path[2]=0;
		}
		path[3]=parseInt(draggeddiv)-99;	//-------to move one step diagonally left
		q=checkrange(path[3]);
		if(!q)
		{
			path[3]=0;
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[0]!=0)
			{
				x=document.getElementById(path[0]).contains(document.getElementById(imageid[i]));
				if(x)
				{
					break;
				}
			}
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[1]!=0)
			{			
				y=document.getElementById(path[1]).contains(document.getElementById(imageid[i]));
				if(y)
				{
					break;
				}
			}
		}
		if(!x)	
		{
		//	alert("x:" +x);
			document.getElementById(path[0]).style.background="grey";
		}
		if(!x && !y)
		{
			for(var j=0;j<movetrack.length;j++)
			{
				if(movetrack[j]==data)
				{
					moved="true";
					break;
				}
				moved="false";
			}
			if(moved=="true")
			{
				document.getElementById(path[0]).style.background="grey";
			}
			else
			{
				document.getElementById(path[0]).style.background="grey";
				document.getElementById(path[1]).style.background="grey";
			}
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[2]!=0)
			{
				z=document.getElementById(path[2]).contains(document.getElementById(imageid[i]));
				if(z)
				{
					img=imageid[i];
					if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
						(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))
					{
							document.getElementById(path[2]).style.background="grey";
					}
					break;
				}
			}
		
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[3]!=0)
			{
				w=document.getElementById(path[3]).contains(document.getElementById(imageid[i]));
				if(w)
				{
					img=imageid[i];
					if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
						(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))
					{
							document.getElementById(path[3]).style.background="grey";
					}
					break;
				}
			}
		}
	}
	else
	{
		
		var x,y,z,w;
		var q;
		var img;
		path[0]=parseInt(draggeddiv)-1;	//---------to move one step infront
		q=checkrange(path[0]);
		if(!q)
		{
			path[0]=0;
		}
		path[1]=parseInt(draggeddiv)-2;	//--------------to move two steps infront
		q=checkrange(path[1]);
		if(!q)
		{
			path[1]=0;
		}
		path[2]=parseInt(draggeddiv)+99;	//-------to move one step diagonally right
		q=checkrange(path[2]);
		if(!q)
		{
			path[2]=0;
		}
		path[3]=parseInt(draggeddiv)-101;	//-------to move one step diagonally left
		q=checkrange(path[3]);
		if(!q)
		{
			path[3]=0;
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[0]!=0)
			{
				x=document.getElementById(path[0]).contains(document.getElementById(imageid[i]));
				if(x)
				{
					break;
				}
			}
		}
		for(var i=0;i<imageid.length;i++)
		{	
			if(path[1]!=0)
			{
				y=document.getElementById(path[1]).contains(document.getElementById(imageid[i]));
				if(y)
				{
					break;
				}
			}
		}
		if(!x)	//contains an image
		{
			document.getElementById(path[0]).style.background="grey";
		}
		if(!x && !y)
		{
			for(var j=0;j<movetrack.length;j++)
			{
				if(movetrack[j]==data)
				{
					moved="true";
					break;
				}
				moved="false";
			}
			if(moved=="true")
			{
				document.getElementById(path[0]).style.background="grey";
			}
			else
			{
				document.getElementById(path[0]).style.background="grey";
				document.getElementById(path[1]).style.background="grey";
			}
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[2]!=0)
			{
				z=document.getElementById(path[2]).contains(document.getElementById(imageid[i]));
				if(z)
				{
					img=imageid[i];
					if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
						(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
					{
					
							document.getElementById(path[2]).style.background="grey";
					}
					break;
				}
			}
		}
		for(var i=0;i<imageid.length;i++)
		{
			if(path[3]!=0)
			{
				w=document.getElementById(path[3]).contains(document.getElementById(imageid[i]));
				if(w)
				{
					img=imageid[i];
					if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
						(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
					{
							document.getElementById(path[3]).style.background="grey";
					}
					break;
				}
			}
		}
	}
}

//-----------------------------------------------function for pawn to capture----------------------------------------------
function pawncapture(x,data,img,ev)
{
	if(!x)	//--------if the dropzone is empty---
	{						
		//-------resets turn because invalid move-----
		alert("invalid move");
		if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
		{
			turn=0;
			document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
			return false;
		}
		else
		{
			turn=1;
			document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
			return false;
		}
				
	}
	if(x)//--------if the dropzone is not empty and conatins an image---
	{
		
		if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8"))	//checks if white pawn
		{
			if((img=="bp1")||(img=="bp2")||(img=="bp3")||(img=="bp4")||(img=="bp5")||(img=="bp6")||(img=="bp7")||(img=="bp8")||(img=="br1")||	
					(img=="bn1")||(img=="bb1")||(img=="bq1")||(img=="bk1")||(img=="bb2")||(img=="bn2")||(img=="br2"))	//since it is a white pawn it can capture any black piece
			{
				
				//------------ removes  chess piece of the opponent from the dropzone.---------
					var el = ev.target;
					if (!el.classList.contains('dropzone')) 
					{
						
					   el = ev.target.parentNode;
					   ev.target.remove();
					   var chk=checkemptydivblack();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
					}
					 el.appendChild(document.getElementById(data));
					 
				//-------------------------------------checks for illegal move--------------------	
					var t=check();
				//	alert("t: "+t);
					if(t=="wk1")
					{
						alert("ILLEGAL MOVE!!")
						turn=0;
						document.getElementById("bturn1").innerHTML="";
						document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
						document.getElementById("wturn2").innerHTML="TURN";
						document.getElementById(draggeddiv).appendChild(document.getElementById(data));
						document.getElementById(idtest).appendChild(ev.target);
						return false;
					}
					else if(t=="bk1")
					{
						checkmate(t);
					}
			}
			else			//----------reset turn if dropzone contains white piece----------
			{
				alert("Invalid Move!!");
				document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
				turn=0;
				return false;
			}
		}
		else if((data=="bp1")||(data=="bp2")||(data=="bp3")||(data=="bp4")||(data=="bp5")||(data=="bp6")||(data=="bp7")||(data=="bp8"))
		{
			if((img=="wp1")||(img=="wp2")||(img=="wp3")||(img=="wp4")||(img=="wp5")||(img=="wp6")||(img=="wp7")||(img=="wp8")||(img=="wr1")||
					(img=="wn1")||(img=="wb1")||(img=="wq1")||(img=="wk1")||(img=="wb2")||(img=="wn2")||(img=="wr2"))
			{
					
					//------------ removes  chess piece of the opponent from the dropzone.---------
					var el = ev.target;
				//	alert("el :" +el); //htmlimageelement
					if (!el.classList.contains('dropzone')) 
					{
					   el = ev.target.parentNode; //htmldivelement
//					   alert("here: "+el);
					   ev.target.remove();
					    var chk=checkemptydivwhite();
					  // alert("le"+chk);
					   if(chk!=0)
					   {
							document.getElementById(chk).appendChild(ev.target);
					   }
					}
					 el.appendChild(document.getElementById(data));
				
				//-------------------------checks for illegal move--------------------------
					var t=check();
					//alert("tt: "+t);
					if(t=="bk1")
					{
						alert("ILLEGAL MOVE!!")
						turn=1;
						document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
						document.getElementById(draggeddiv).appendChild(document.getElementById(data));
						document.getElementById(idtest).appendChild(ev.target);
						return false;
					}
					else if(t=="wk1")
					{
						checkmate(t);
					}
				
			}
			else			//----------reset turn if two black piece----------
			{
				alert("Invalid Move!!");
				turn=1;
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
				return false;
			}
		}
		
		
	}
}
//----------------------------------------function for pawn check-----------------------------------------------------------------
function pawncheck(data,idd)
{
	
	var ld,rd;
	var kingcheck1;
	var kingcheck2;
	var inrange=0;
	if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8"))
	{
		rd=parseInt(idd)+101;	//-------fetch id of diagonally right div from the id of div where pawn is dropped--
		ld=parseInt(idd)-99;	//-------fetch id of diagonally left div--
		if((rd>=101 && rd<=108)||(rd>=201 && rd<=208)||(rd>=301 && rd<=308)||(rd>=401 && rd<=408)||
			(rd>=501 && rd<=508)||(rd>=601 && rd<=608)||(rd>=701 && rd<=708)||(rd>=801 && rd<=808))
		{
			kingcheck1=document.getElementById(rd).contains(document.getElementById("bk1"));	//checks if diagonally right div contains king
		}
		else{
			kingcheck1="";
		}
		
		if((ld>=101 && ld<=108)||(ld>=201 && ld<=208)||(ld>=301 && ld<=308)||(ld>=401 && ld<=408)||
		(ld>=501 && ld<=508)||(ld>=601 && ld<=608)||(ld>=701 && ld<=708)||(ld>=801 && ld<=808))
		{
			kingcheck2=document.getElementById(ld).contains(document.getElementById("bk1"));	//checks if diagonally left div contains king
		}
		else{
			kingcheck2="";
		}
		
		if((kingcheck1)||(kingcheck2))	//if king present
		{
			
			alert("CHECK!!!");
			document.getElementById(parseInt(idd)).style.border="2px solid red";
			return "bk1";
		}
		else
		{
			return false;
		}
	}
	if((data=="bp1")||(data=="bp2")||(data=="bp3")||(data=="bp4")||(data=="bp5")||(data=="bp6")||(data=="bp7")||(data=="bp8"))
	{
		rd=parseInt(idd)+99;	//-------fetch id of diagonally right
		ld=parseInt(idd)-101;	//-------fetch id of diagonally left
		if((rd>=101 && rd<=108)||(rd>=201 && rd<=208)||(rd>=301 && rd<=308)||(rd>=401 && rd<=408)||
			(rd>=501 && rd<=508)||(rd>=601 && rd<=608)||(rd>=701 && rd<=708)||(rd>=801 && rd<=808))
		{
			kingcheck1=document.getElementById(rd).contains(document.getElementById("wk1"));	//checks if diagonally right div contains king
		}
		else{
			kingcheck1="";
		}
		
		if((ld>=101 && ld<=108)||(ld>=201 && ld<=208)||(ld>=301 && ld<=308)||(ld>=401 && ld<=408)||
		(ld>=501 && ld<=508)||(ld>=601 && ld<=608)||(ld>=701 && ld<=708)||(ld>=801 && ld<=808))
		{
			kingcheck2=document.getElementById(ld).contains(document.getElementById("wk1"));	//checks if diagonally left div contains king
		}
		else{
			kingcheck2="";
		}

		
		if((kingcheck1)||(kingcheck2))	//if king present
		{
			alert("CHECK!!!");
			document.getElementById(parseInt(idd)).style.border="2px solid red";
			return "wk1";
		}
		else
		{
			return false;
		}
	}
}
//--------------------------------------function for pawn move----------------------------------------------------------------------

function pawnmove(data,ev,idd)
{
		var c1,c2,c3,lc4;
		if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8"))
		{
			
			c1=parseInt(draggeddiv)+1;	//---------to move one step infront
			c2=parseInt(draggeddiv)+2;	//--------------to move two steps infront
			c3=parseInt(draggeddiv)+101;	//-------to move one step diagonally right
			lc4=parseInt(draggeddiv)-99;	//-------to move one step diagonally left
		}
		if((data=="bp1")||(data=="bp2")||(data=="bp3")||(data=="bp4")||(data=="bp5")||(data=="bp6")||(data=="bp7")||(data=="bp8"))
		{
			c1=parseInt(draggeddiv)-1;	//---------to move one step infront
			c2=parseInt(draggeddiv)-2;	//--------------to move two steps infront
			c3=parseInt(draggeddiv)+99;	//-------to move one step diagonally right
			lc4=parseInt(draggeddiv)-101;	//-------to move one step diagonally left
		}
		
		//------------------checks if the dropzone(div with idd) contains an image----------------
		for(var i=0;i<imageid.length;i++)
		{
			x=document.getElementById(idd).contains(document.getElementById(imageid[i]));	
			if(x)	//contains an image
			{
				img=imageid[i];		//image id is stored in variable img
				break;
			}
		}
		//--------------checks if pawn was moved before------------
		for(var j=0;j<movetrack.length;j++)
		{
			if(movetrack[j]==data)
			{
				moved="true";
				break;
			}
				moved="false";
		}
		if(moved=="false") //-----------since moved is false pawn can move 2 steps at the beginning------
		{
				if((idd==c3)||(idd==lc4))	//to move one step diagonally(left or right)
				{
					pawncapture(x,data,img,ev);
				 
				}
				else if((idd==c1)||(idd==c2))	//to move one or two step infront
				{
					if(x)	//contains image in front div
					{
						alert("Invalid Move!!");
						//-----------resets turn-------------
						if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
						{
							turn=0;
							document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
							return false;
						}
						else
						{
							turn=1;
						
					document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
							return false;
						}
						document.getElementById(draggeddiv).style.background="grey";
						return false;
					}
						
					if(!x)
					{
						var q;									//check piece in between
						for(var i=0;i<imageid.length;i++)
						{
							q=document.getElementById(c1).contains(document.getElementById(imageid[i]));	
							if(q)	//contains an image
							{
									alert("Invalid Move!!");
								//-----------resets turn-------------
								if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
								{
									turn=0;
									document.getElementById("bturn1").innerHTML="";
									document.getElementById("bturn2").innerHTML="";
									document.getElementById("wturn1").innerHTML="YOUR";
									document.getElementById("wturn2").innerHTML="TURN";
									return false;
								}
								else
								{
									turn=1;
									document.getElementById("bturn1").innerHTML="YOUR";
									document.getElementById("bturn2").innerHTML="TURN";
									document.getElementById("wturn1").innerHTML="";
									document.getElementById("wturn2").innerHTML="";
									return false;
								}
							}
						}
						ev.target.appendChild(document.getElementById(data));
						
						
						//-------------------------------------checks for illegal move--------------------	
						if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
						{
							var t=check();
							if(t=="wk1")		//white king piece is in check 
							{
								alert("ILLEGAL MOVE!!")
								turn=0;
								document.getElementById("bturn1").innerHTML="";
								document.getElementById("bturn2").innerHTML="";
								document.getElementById("wturn1").innerHTML="YOUR";
								document.getElementById("wturn2").innerHTML="TURN";
								document.getElementById(draggeddiv).appendChild(document.getElementById(data));
								document.getElementById(idtest).appendChild(ev.target);
								return false;
							}
							else
							{
								movetrack[k]=data;
								k++;
								if(t=="bk1")
								{
									checkmate(t);
								}
							}
						}
						else{
							var t=check();
							if(t=="bk1")
							{
								alert("ILLEGAL MOVE!!")
								turn=1;
								document.getElementById("bturn1").innerHTML="YOUR";
								document.getElementById("bturn2").innerHTML="TURN";
								document.getElementById("wturn1").innerHTML="";
								document.getElementById("wturn2").innerHTML="";
								document.getElementById(draggeddiv).appendChild(document.getElementById(data));
								document.getElementById(idtest).appendChild(ev.target);
								return false;
							}
							else
							{
								movetrack[k]=data;
								k++;
								if(t=="wk1")
								{
									checkmate(t);
								}
							}
						}
					}
				}
				else
				{
						alert("Invalid Move!!");
						//-----------resets turn-------------
						if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
						{
							turn=0;
							document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
							return false;
						}
						else
						{
							turn=1;
							document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
							return false;
						}
				}
			return true;
		}
		else if(moved=="true")
		{
				if((idd==c3)||(idd==lc4))	//to move one step diagonally(left or right)
				{
					pawncapture(x,data,img,ev);
					
				}
				else if(idd==c1)
				{
					if(x)	//---contains image in front div
					{
						alert("Invalid Move!!");
						document.getElementById(draggeddiv).style.background="grey";
						//-----------resets turn-------------
						if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
						{
							turn=0;
							document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
							return false;
						}
						else
						{
							turn=1;
							document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
							return false;
						}
						
					}	
					//alert("x: "+x);
					if(!x)
					{
						ev.target.appendChild(document.getElementById(data));
						
						//-------------------------------------checks for illegal move--------------------	
						if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
						{
							var t=check();
							if(t=="wk1")
							{
								alert("ILLEGAL MOVE!!")
								turn=0;
								document.getElementById("bturn1").innerHTML="";
								document.getElementById("bturn2").innerHTML="";
								document.getElementById("wturn1").innerHTML="YOUR";
								document.getElementById("wturn2").innerHTML="TURN";
								document.getElementById(draggeddiv).appendChild(document.getElementById(data));
								document.getElementById(idtest).appendChild(ev.target);
								return false;
							}
							else if(t=="bk1")
							{
								checkmate(t);
							}
						}
						else{
							var t=check();
							if(t=="bk1")
							{
								alert("ILLEGAL MOVE!!")
								turn=1;
								document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
								document.getElementById(draggeddiv).appendChild(document.getElementById(data));
								document.getElementById(idtest).appendChild(ev.target);
								return false;
							}
							else if(t=="wk1")
							{
								checkmate(t);
							}
						}
					}
				}
				else
				{
						alert("Invalid Move!!");
						//-----------resets turn-------------
						if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||(data=="wr1")||(data=="wn1")||(data=="wb1")||(data=="wq1")||(data=="wk1")||(data=="wb2")||(data=="wn2")||(data=="wr2"))
						{
							turn=0;
							document.getElementById("bturn1").innerHTML="";
					document.getElementById("bturn2").innerHTML="";
						document.getElementById("wturn1").innerHTML="YOUR";
					document.getElementById("wturn2").innerHTML="TURN";
							return false;
						}
						else
						{
							turn=1;
							document.getElementById("bturn1").innerHTML="YOUR";
					document.getElementById("bturn2").innerHTML="TURN";
						document.getElementById("wturn1").innerHTML="";
					document.getElementById("wturn2").innerHTML="";
							return false;
						}
				}
		}
		 pawncheck(data,idd);
	
		
}
