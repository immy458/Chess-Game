function formshow()
{
	document.getElementById("playerdetails").style.visibility="visible";
}
function formsubmit()
{
	var x = document.forms["form"]["player1name"].value;
	  if (x == "") {
		alert("Player 1 name must be filled out");
		return false;
	  }
	 
	  var y = document.forms["form"]["player2name"].value;
	  if (y == "") {
		alert("Player 2 name must be filled out");
		return false;
	  }
}