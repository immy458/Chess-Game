function check()
{ 
	//alert("hey");
	var x;
	var z,z1,z2;
	var data;
	for(var e=101;e<=808;e++)
	{
		if((e>=101 && e<=108)||(e>=201 && e<=208)||(e>=301 && e<=308)||(e>=401 && e<=408)||
			(e>=501 && e<=508)||(e>=601 && e<=608)||(e>=701 && e<=708)||(e>=801 && e<=808))
		{
			//alert(e);
			for(var i=0;i<imageid.length;i++)
			{
				x=document.getElementById(e).contains(document.getElementById(imageid[i]));	
			
				if(x)						
				{
					data=imageid[i];
					//alert(data);
			
					if((data=="wp1")||(data=="wp2")||(data=="wp3")||(data=="wp4")||(data=="wp5")||(data=="wp6")||(data=="wp7")||(data=="wp8")||
					(data=="bp1")||(data=="bp2")||(data=="bp3")||(data=="bp4")||(data=="bp5")||(data=="bp6")||(data=="bp7")||(data=="bp8"))
					{
					
						z=pawncheck(data,e);
						
						if(z)
						{
						
							return z;
							
						}
						
						break;
					}
					else if((data=="wr1")||(data=="wr2")||(data=="br1")||(data=="br2"))
					{
						
						z=rookcheck(data,e);
						//alert("zz:"+z+ " e: " +e);
						if(z)
						{
							
							return z;
						}
						break;
					}
					else if((data=="wn1")||(data=="wn2")||(data=="bn1")||(data=="bn2"))
					{
						 z=knightcheck(e,data);
						 if(z)
						{
							return z;
						}
						 break;
					}
					else if((data=="wb1")||(data=="wb2")||(data=="bb1")||(data=="bb2"))
					{
						z=bishopcheck(data,e);
						if(z)
						{
							return z;
						}
						break;
					}
					else if((data=="wq1")||(data=="bq1"))
					{
						z1=rookcheck(data,e);
						if(z1)
						{
						//	alert("z111: "+z1);
							return z1;
						}
						z2=bishopcheck(data,e);
						if(z2)
						{
						//	alert("z22: "+z1);
							return z2;
						}
						break;
					}
					else if((data=="wk1")||(data=="bk1"))
					{
						z=kingcheck(data,e);
						if(z)
						{
						//	alert("z111: "+z1);
							return z;
						}
						break;
					}
				}
				
			}
		}
	}
	
}